const {
  initializeTestEnvironment,
  assertFails,
  assertSucceeds,
} = require("@firebase/rules-unit-testing");
const { test, before, after, beforeEach } = require("node:test");
const fs = require("node:fs");

let testEnv;
const PROJECT_ID = process.env.GCP_PROJECT || "demo-no-project";
const ALICE_UID = "alice_123";
const BOB_UID = "bob_456";

const [emulatorHost, emulatorPortStr] = (process.env.FIRESTORE_EMULATOR_HOST || "127.0.0.1:8085").split(":");
const emulatorPort = parseInt(emulatorPortStr, 10);

function ts() {
  return new Date(Date.now() - 1000);
}

function validProfile(uid) {
  return {
    userId: uid,
    displayName: "Alice Runner",
    handle: "@alice",
    bio: "Emerald consistency",
    totalScore: 45,
    todayScore: 15,
    currentStreak: 3,
    bestDayScore: 30,
    totalPositiveLogged: 5,
    totalNegativeLogged: 1,
    createdAt: ts(),
    updatedAt: ts(),
  };
}

function validTask(uid) {
  return {
    userId: uid,
    title: "Morning Run",
    category: "Fitness",
    type: "POSITIVE",
    points: 20,
    isActive: true,
    sortOrder: 0,
    createdAt: ts(),
    updatedAt: ts(),
  };
}

function validDailyLog(uid, dateKey, netScore = -15) {
  return {
    userId: uid,
    dateKey: dateKey,
    completedTaskIds: ["task_1"],
    positivePoints: netScore >= 0 ? netScore : 10,
    negativePoints: netScore >= 0 ? 0 : 25,
    netScore: netScore,
    positiveCount: 1,
    negativeCount: netScore >= 0 ? 0 : 1,
    createdAt: ts(),
    updatedAt: ts(),
  };
}

function validLeaderboardEntry(uid, totalScore = -10) {
  return {
    userId: uid,
    displayName: "Alice Runner",
    handle: "@alice",
    bio: "Daily discipline",
    totalScore: totalScore,
    todayScore: -15,
    currentStreak: 0,
    bestDayScore: 25,
    updatedAt: ts(),
  };
}

before(async () => {
  const rules = fs.readFileSync("./firestore.rules", "utf8");
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      rules,
      host: emulatorHost,
      port: emulatorPort,
    },
  });
});

after(async () => {
  if (testEnv) {
    await testEnv.cleanup();
  }
});

beforeEach(async () => {
  if (testEnv) {
    await testEnv.clearFirestore();
  }
});

test("Unauthenticated user: cannot read or write any LifeScore collection", async () => {
  const unauthDb = testEnv.unauthenticatedContext().firestore();
  await assertFails(unauthDb.collection("users").doc(ALICE_UID).get());
  await assertFails(unauthDb.collection("users").doc(ALICE_UID).collection("tasks").get());
  await assertFails(unauthDb.collection("users").doc(ALICE_UID).collection("daily_logs").get());
  await assertFails(unauthDb.collection("leaderboard").get());
});

test("Owner can create and read own private profile, tasks, and negative daily log", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  await assertSucceeds(aliceDb.collection("users").doc(ALICE_UID).set(validProfile(ALICE_UID)));
  await assertSucceeds(aliceDb.collection("users").doc(ALICE_UID).get());
  await assertSucceeds(aliceDb.collection("users").doc(ALICE_UID).collection("tasks").doc("task_1").set(validTask(ALICE_UID)));
  await assertSucceeds(aliceDb.collection("users").doc(ALICE_UID).collection("tasks").get());
  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).collection("daily_logs").doc("2026-11-15").set(validDailyLog(ALICE_UID, "2026-11-15", -15))
  );
  await assertSucceeds(aliceDb.collection("users").doc(ALICE_UID).collection("daily_logs").get());
});

test("Cross-user isolation: Bob cannot read or write Alice private profile, tasks, or logs", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  await assertSucceeds(aliceDb.collection("users").doc(ALICE_UID).set(validProfile(ALICE_UID)));
  await assertSucceeds(aliceDb.collection("users").doc(ALICE_UID).collection("tasks").doc("task_1").set(validTask(ALICE_UID)));
  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).collection("daily_logs").doc("2026-11-15").set(validDailyLog(ALICE_UID, "2026-11-15", 10))
  );

  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  await assertFails(bobDb.collection("users").doc(ALICE_UID).get());
  await assertFails(bobDb.collection("users").doc(ALICE_UID).collection("tasks").get());
  await assertFails(bobDb.collection("users").doc(ALICE_UID).collection("daily_logs").get());
  await assertFails(bobDb.collection("users").doc(ALICE_UID).set(validProfile(ALICE_UID)));
  await assertFails(bobDb.collection("users").doc(ALICE_UID).collection("tasks").doc("task_2").set(validTask(BOB_UID)));
});

test("Leaderboard: authenticated users can list global rankings, only owner can write own entry", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  await assertSucceeds(aliceDb.collection("leaderboard").doc(ALICE_UID).set(validLeaderboardEntry(ALICE_UID, -10)));

  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  await assertSucceeds(bobDb.collection("leaderboard").get());
  await assertFails(bobDb.collection("leaderboard").doc(ALICE_UID).set(validLeaderboardEntry(ALICE_UID, 9999)));
});

test("Shadow field and invalid type rejection", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  await assertFails(
    aliceDb.collection("users").doc(ALICE_UID).set({
      ...validProfile(ALICE_UID),
      isAdmin: true,
    })
  );
  await assertFails(
    aliceDb.collection("users").doc(ALICE_UID).collection("tasks").doc("bad_task").set({
      ...validTask(ALICE_UID),
      type: "UNKNOWN",
    })
  );
  await assertFails(
    aliceDb.collection("users").doc(ALICE_UID).collection("daily_logs").doc("invalid_date").set(validDailyLog(ALICE_UID, "invalid_date", 10))
  );
});
