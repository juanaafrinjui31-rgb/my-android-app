package com.example.domain

import com.example.data.model.DailyLog
import com.example.data.model.HabitTask
import com.example.data.model.TaskType
import org.junit.Assert.assertEquals
import org.junit.Test

class LifeScoreAnalyticsTest {

  @Test
  fun calculateDayBreakdown_positiveAndNegative_computesSignedNetScore() {
    val tasks =
      listOf(
        HabitTask(id = "t1", title = "Run", type = TaskType.POSITIVE.wireValue, points = 20L),
        HabitTask(id = "t2", title = "Read", type = TaskType.POSITIVE.wireValue, points = 15L),
        HabitTask(id = "t3", title = "Scroll", type = TaskType.NEGATIVE.wireValue, points = 50L),
      )

    val result = LifeScoreAnalytics.calculateDayBreakdown(tasks, setOf("t1", "t3"))

    assertEquals(20L, result.positivePoints)
    assertEquals(50L, result.negativePoints)
    assertEquals(-30L, result.netScore)
    assertEquals(1L, result.positiveCount)
    assertEquals(1L, result.negativeCount)
  }

  @Test
  fun buildPeriodSummary_weeklyAndMonthly_includesNegativeDays() {
    val today = LifeScoreAnalytics.todayDateKey()
    val yesterday = LifeScoreAnalytics.dateKeyDaysAgo(1)
    val logs =
      listOf(
        DailyLog(dateKey = today, positivePoints = 30L, negativePoints = 10L, netScore = 20L),
        DailyLog(dateKey = yesterday, positivePoints = 5L, negativePoints = 35L, netScore = -30L),
      )

    val weekly =
      LifeScoreAnalytics.buildPeriodSummary(
        period = ProgressPeriod.WEEKLY,
        logs = logs,
        tasks = emptyList(),
        todayKey = today,
      )
    assertEquals(7, weekly.graphPoints.size)
    assertEquals(-10L, weekly.netScore)
    assertEquals(20L, weekly.bestScore)
    assertEquals(-30L, weekly.lowestScore)

    val monthly =
      LifeScoreAnalytics.buildPeriodSummary(
        period = ProgressPeriod.MONTHLY,
        logs = logs,
        tasks = emptyList(),
        todayKey = today,
      )
    assertEquals(30, monthly.graphPoints.size)
    assertEquals(-10L, monthly.netScore)
  }
}
