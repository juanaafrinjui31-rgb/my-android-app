package com.example.data.repository

import com.example.base.FirestoreEmulatorTestBase
import com.example.data.model.TaskType
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withTimeout
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test
import java.util.UUID

class LifeScoreRepositoryRuleTest : FirestoreEmulatorTestBase() {

  @Test
  fun ensureUserInitialized_authenticatedUser_createsProfileLeaderboardAndTasks() = runBlocking {
    val uid = signInTestUser("alice_${UUID.randomUUID()}@test.com")
    val repo = LifeScoreRepository(firestore, auth)

    withTimeout(DEFAULT_TIMEOUT_MS) {
      repo.ensureUserInitialized("Alice Emerald", "alice@test.com", null)
    }

    val profile = withTimeout(FLOW_TIMEOUT_MS) {
      repo.observeUserProfile(uid).first { it != null }
    }
    assertNotNull(profile)
    assertEquals("Alice Emerald", profile?.displayName)

    val tasks = withTimeout(FLOW_TIMEOUT_MS) {
      repo.observeTasks(uid).first { it.isNotEmpty() }
    }
    assertTrue(tasks.size >= 5)

    val lb = withTimeout(FLOW_TIMEOUT_MS) {
      repo.observeLeaderboard().first { list -> list.any { it.userId == uid } }
    }
    assertTrue(lb.any { it.userId == uid })
  }

  @Test
  fun toggleTaskForDate_negativeAndPositiveTasks_updatesNetScoreAndLeaderboard() = runBlocking {
    val uid = signInTestUser("scorer_${UUID.randomUUID()}@test.com")
    val repo = LifeScoreRepository(firestore, auth)

    withTimeout(DEFAULT_TIMEOUT_MS) {
      repo.ensureUserInitialized("Scorer", "scorer@test.com", null)
    }

    val tasks = withTimeout(FLOW_TIMEOUT_MS) {
      repo.observeTasks(uid).first { it.isNotEmpty() }
    }
    val negTask = tasks.first { it.taskType == TaskType.NEGATIVE }
    val dateKey = "2026-11-15"

    withTimeout(DEFAULT_TIMEOUT_MS) {
      repo.toggleTaskForDate(
        dateKey = dateKey,
        taskId = negTask.id,
        allTasks = tasks,
        existingLogs = emptyList(),
        todayKey = dateKey,
      )
    }

    val logs = withTimeout(FLOW_TIMEOUT_MS) {
      repo.observeDailyLogs(uid).first { list -> list.any { it.dateKey == dateKey } }
    }
    val todayLog = logs.first { it.dateKey == dateKey }
    assertEquals(-negTask.points, todayLog.netScore)

    val updatedProfile = withTimeout(FLOW_TIMEOUT_MS) {
      repo.observeUserProfile(uid).first { it?.todayScore == -negTask.points }
    }
    assertEquals(-negTask.points, updatedProfile?.totalScore)
  }

  @Test
  fun crossUserIsolation_bobCannotReadAlicePrivateProfileOrTasks() = runBlocking {
    val aliceUid = signInTestUser("alice_iso_${UUID.randomUUID()}@test.com")
    val aliceRepo = LifeScoreRepository(firestore, auth)
    withTimeout(DEFAULT_TIMEOUT_MS) {
      aliceRepo.ensureUserInitialized("Alice Private", "alice@test.com", null)
    }

    signInTestUser("bob_iso_${UUID.randomUUID()}@test.com")
    val bobRepo = LifeScoreRepository(firestore, auth)

    try {
      withTimeout(DEFAULT_TIMEOUT_MS) {
        firestore.collection("users").document(aliceUid).get().await()
      }
      fail("Expected PERMISSION_DENIED when Bob reads Alice profile")
    } catch (e: FirebaseFirestoreException) {
      assertEquals(FirebaseFirestoreException.Code.PERMISSION_DENIED, e.code)
    }

    try {
      withTimeout(FLOW_TIMEOUT_MS) {
        bobRepo.observeTasks(aliceUid).first()
      }
      fail("Expected PERMISSION_DENIED when Bob observes Alice tasks")
    } catch (e: Exception) {
      val firestoreException = e.unwrapFirestoreException()
      assertNotNull("Expected nested FirebaseFirestoreException, got $e", firestoreException)
      assertEquals(FirebaseFirestoreException.Code.PERMISSION_DENIED, firestoreException?.code)
    }
  }

  @Test
  fun unauthenticatedCaller_observeTasksAndLeaderboard_failsWithPermissionDenied() = runBlocking {
    auth.signOut()
    val repo = LifeScoreRepository(firestore, auth)

    try {
      withTimeout(FLOW_TIMEOUT_MS) {
        repo.observeLeaderboard().first()
      }
      fail("Expected PERMISSION_DENIED when unauthenticated user observes leaderboard")
    } catch (e: Exception) {
      val firestoreException = e.unwrapFirestoreException()
      assertNotNull("Expected nested FirebaseFirestoreException, got $e", firestoreException)
      assertEquals(FirebaseFirestoreException.Code.PERMISSION_DENIED, firestoreException?.code)
    }
  }

  private companion object {
    const val DEFAULT_TIMEOUT_MS = 5000L
    const val FLOW_TIMEOUT_MS = 3000L
  }
}
