package com.example.data.model

import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.ServerTimestamp

enum class TaskType(val wireValue: String) {
  POSITIVE("POSITIVE"),
  NEGATIVE("NEGATIVE");

  companion object {
    fun fromWire(value: String): TaskType =
      entries.firstOrNull { it.wireValue == value } ?: POSITIVE
  }
}

@IgnoreExtraProperties
data class HabitTask(
  @DocumentId val id: String = "",
  val userId: String = "",
  val title: String = "",
  val category: String = "Wellness",
  val type: String = TaskType.POSITIVE.wireValue,
  val points: Long = 10L,
  val isActive: Boolean = true,
  val sortOrder: Long = 0L,
  @ServerTimestamp val createdAt: Timestamp? = null,
  @ServerTimestamp val updatedAt: Timestamp? = null,
) {
  val taskType: TaskType
    get() = TaskType.fromWire(type)

  val signedPoints: Long
    get() = if (taskType == TaskType.POSITIVE) points else -points
}

@IgnoreExtraProperties
data class DailyLog(
  @DocumentId val id: String = "",
  val userId: String = "",
  val dateKey: String = "",
  val completedTaskIds: List<String> = emptyList(),
  val positivePoints: Long = 0L,
  val negativePoints: Long = 0L,
  val netScore: Long = 0L,
  val positiveCount: Long = 0L,
  val negativeCount: Long = 0L,
  @ServerTimestamp val createdAt: Timestamp? = null,
  @ServerTimestamp val updatedAt: Timestamp? = null,
)

@IgnoreExtraProperties
data class UserProfile(
  @DocumentId val id: String = "",
  val userId: String = "",
  val displayName: String = "",
  val handle: String = "",
  val bio: String = "",
  val photoUrl: String = "",
  val totalScore: Long = 0L,
  val todayScore: Long = 0L,
  val currentStreak: Long = 0L,
  val bestDayScore: Long = 0L,
  val totalPositiveLogged: Long = 0L,
  val totalNegativeLogged: Long = 0L,
  @ServerTimestamp val createdAt: Timestamp? = null,
  @ServerTimestamp val updatedAt: Timestamp? = null,
)

@IgnoreExtraProperties
data class LeaderboardEntry(
  @DocumentId val id: String = "",
  val userId: String = "",
  val displayName: String = "",
  val handle: String = "",
  val bio: String = "",
  val photoUrl: String = "",
  val totalScore: Long = 0L,
  val todayScore: Long = 0L,
  val currentStreak: Long = 0L,
  val bestDayScore: Long = 0L,
  @ServerTimestamp val updatedAt: Timestamp? = null,
)
