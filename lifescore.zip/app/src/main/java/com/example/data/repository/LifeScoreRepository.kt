package com.example.data.repository

import android.content.Context
import com.example.R
import com.example.data.model.DailyLog
import com.example.data.model.HabitTask
import com.example.data.model.LeaderboardEntry
import com.example.data.model.TaskType
import com.example.data.model.UserProfile
import com.example.data.remote.OperationType
import com.example.data.remote.handleFirestoreError
import com.example.domain.LifeScoreAnalytics
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await

class LifeScoreRepository(
  private val db: FirebaseFirestore,
  private val auth: FirebaseAuth = Firebase.auth,
) {
  constructor(context: Context) : this(
    FirebaseFirestore.getInstance(
      context.applicationContext.getString(R.string.firestore_database_id)
    ),
    Firebase.auth,
  )

  private fun requireUserId(): String {
    return auth.currentUser?.uid
      ?: throw IllegalStateException("User must be signed in with Google before accessing Firestore.")
  }

  fun observeUserProfile(userId: String): Flow<UserProfile?> {
    val docRef = db.collection("users").document(userId)
    return docRef.snapshots()
      .map { snapshot ->
        snapshot.toObject(
          UserProfile::class.java,
          DocumentSnapshot.ServerTimestampBehavior.ESTIMATE,
        )
      }
      .catch { error ->
        val firestoreError =
          generateSequence(error) { it.cause }
            .filterIsInstance<FirebaseFirestoreException>()
            .firstOrNull()
        if (firestoreError == null && error is CancellationException) throw error
        val exceptionToLog = firestoreError ?: (error as? Exception)
        if (exceptionToLog != null && auth.currentUser?.uid == userId) {
          handleFirestoreError(exceptionToLog, OperationType.GET, docRef.path)
        }
        throw error
      }
  }

  fun observeTasks(userId: String): Flow<List<HabitTask>> {
    val colRef = db.collection("users").document(userId).collection("tasks")
    return colRef.orderBy("sortOrder", Query.Direction.ASCENDING)
      .snapshots()
      .map { snapshot ->
        snapshot.toObjects(
          HabitTask::class.java,
          DocumentSnapshot.ServerTimestampBehavior.ESTIMATE,
        )
      }
      .catch { error ->
        val firestoreError =
          generateSequence(error) { it.cause }
            .filterIsInstance<FirebaseFirestoreException>()
            .firstOrNull()
        if (firestoreError == null && error is CancellationException) throw error
        val exceptionToLog = firestoreError ?: (error as? Exception)
        if (exceptionToLog != null && auth.currentUser?.uid == userId) {
          handleFirestoreError(exceptionToLog, OperationType.LIST, colRef.path)
        }
        throw error
      }
  }

  fun observeDailyLogs(userId: String): Flow<List<DailyLog>> {
    val colRef = db.collection("users").document(userId).collection("daily_logs")
    return colRef.orderBy("dateKey", Query.Direction.ASCENDING)
      .snapshots()
      .map { snapshot ->
        snapshot.toObjects(
          DailyLog::class.java,
          DocumentSnapshot.ServerTimestampBehavior.ESTIMATE,
        )
      }
      .catch { error ->
        val firestoreError =
          generateSequence(error) { it.cause }
            .filterIsInstance<FirebaseFirestoreException>()
            .firstOrNull()
        if (firestoreError == null && error is CancellationException) throw error
        val exceptionToLog = firestoreError ?: (error as? Exception)
        if (exceptionToLog != null && auth.currentUser?.uid == userId) {
          handleFirestoreError(exceptionToLog, OperationType.LIST, colRef.path)
        }
        throw error
      }
  }

  fun observeLeaderboard(limit: Long = 50L): Flow<List<LeaderboardEntry>> {
    val colRef = db.collection("leaderboard")
    return colRef
      .orderBy("totalScore", Query.Direction.DESCENDING)
      .limit(limit)
      .snapshots()
      .map { snapshot ->
        snapshot.toObjects(
          LeaderboardEntry::class.java,
          DocumentSnapshot.ServerTimestampBehavior.ESTIMATE,
        )
      }
      .catch { error ->
        val firestoreError =
          generateSequence(error) { it.cause }
            .filterIsInstance<FirebaseFirestoreException>()
            .firstOrNull()
        if (firestoreError == null && error is CancellationException) throw error
        val exceptionToLog = firestoreError ?: (error as? Exception)
        if (exceptionToLog != null && auth.currentUser != null) {
          handleFirestoreError(exceptionToLog, OperationType.LIST, colRef.path)
        }
        throw error
      }
  }

  suspend fun ensureUserInitialized(
    displayNameInput: String?,
    emailInput: String?,
    photoUrlInput: String?,
  ) {
    val uid = requireUserId()
    val userRef = db.collection("users").document(uid)
    val leaderboardRef = db.collection("leaderboard").document(uid)
    val tasksCol = userRef.collection("tasks")

    try {
      val existingSnapshot = userRef.get().await()
      if (!existingSnapshot.exists()) {
        val cleanName =
          displayNameInput?.trim()?.takeIf { it.isNotEmpty() }?.take(50) ?: "LifeScore Member"
        val rawHandle =
          (emailInput?.substringBefore("@") ?: cleanName.lowercase().replace(" ", "_"))
            .replace(Regex("[^a-zA-Z0-9_]"), "")
            .take(24)
            .ifBlank { "member" }
        val handle = "@$rawHandle"
        val cleanPhoto = photoUrlInput?.take(500) ?: ""

        val profileData =
          mapOf(
            "userId" to uid,
            "displayName" to cleanName,
            "handle" to handle,
            "bio" to "Tracking daily habits and building positive momentum.",
            "photoUrl" to cleanPhoto,
            "totalScore" to 0L,
            "todayScore" to 0L,
            "currentStreak" to 0L,
            "bestDayScore" to 0L,
            "totalPositiveLogged" to 0L,
            "totalNegativeLogged" to 0L,
            "createdAt" to FieldValue.serverTimestamp(),
            "updatedAt" to FieldValue.serverTimestamp(),
          )

        val leaderboardData =
          mapOf(
            "userId" to uid,
            "displayName" to cleanName,
            "handle" to handle,
            "bio" to "Tracking daily habits and building positive momentum.",
            "photoUrl" to cleanPhoto,
            "totalScore" to 0L,
            "todayScore" to 0L,
            "currentStreak" to 0L,
            "bestDayScore" to 0L,
            "updatedAt" to FieldValue.serverTimestamp(),
          )

        val batch = db.batch()
        batch.set(userRef, profileData)
        batch.set(leaderboardRef, leaderboardData)

        val existingTasks = tasksCol.limit(1).get().await()
        if (existingTasks.isEmpty) {
          defaultStarterTasks().forEachIndexed { index, starter ->
            val taskRef = tasksCol.document()
            batch.set(
              taskRef,
              mapOf(
                "userId" to uid,
                "title" to starter.title,
                "category" to starter.category,
                "type" to starter.type.wireValue,
                "points" to starter.points,
                "isActive" to true,
                "sortOrder" to index.toLong(),
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp(),
              ),
            )
          }
        }
        batch.commit().await()
      } else {
        // Ensure leaderboard entry exists for existing users
        val lbSnap = leaderboardRef.get().await()
        if (!lbSnap.exists()) {
          val profile = existingSnapshot.toObject(UserProfile::class.java)
          if (profile != null) {
            leaderboardRef
              .set(
                mapOf(
                  "userId" to uid,
                  "displayName" to profile.displayName.ifBlank { "LifeScore Member" },
                  "handle" to profile.handle.ifBlank { "@member" },
                  "bio" to profile.bio.take(160),
                  "photoUrl" to profile.photoUrl.take(500),
                  "totalScore" to profile.totalScore,
                  "todayScore" to profile.todayScore,
                  "currentStreak" to profile.currentStreak,
                  "bestDayScore" to profile.bestDayScore,
                  "updatedAt" to FieldValue.serverTimestamp(),
                )
              )
              .await()
          }
        }
      }
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.WRITE, userRef.path)
      throw e
    }
  }

  suspend fun updateProfile(
    displayName: String,
    handle: String,
    bio: String,
    photoUrl: String,
  ) {
    val uid = requireUserId()
    val cleanName = displayName.trim().take(50)
    require(cleanName.isNotEmpty()) { "Display name cannot be empty" }
    val normalizedHandle =
      handle.trim().let { if (it.startsWith("@")) it else "@$it" }.take(30)
    require(normalizedHandle.length >= 2) { "Handle must be at least 2 characters" }
    val cleanBio = bio.trim().take(160)
    val cleanPhoto = photoUrl.trim().take(500)

    val userRef = db.collection("users").document(uid)
    val lbRef = db.collection("leaderboard").document(uid)

    try {
      val batch = db.batch()
      batch.update(
        userRef,
        mapOf(
          "displayName" to cleanName,
          "handle" to normalizedHandle,
          "bio" to cleanBio,
          "photoUrl" to cleanPhoto,
          "updatedAt" to FieldValue.serverTimestamp(),
        ),
      )
      batch.update(
        lbRef,
        mapOf(
          "displayName" to cleanName,
          "handle" to normalizedHandle,
          "bio" to cleanBio,
          "photoUrl" to cleanPhoto,
          "updatedAt" to FieldValue.serverTimestamp(),
        ),
      )
      batch.commit().await()
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.UPDATE, userRef.path)
      throw e
    }
  }

  suspend fun addTask(
    title: String,
    category: String,
    type: TaskType,
    points: Long,
    sortOrder: Long,
  ): String {
    val uid = requireUserId()
    val cleanTitle = title.trim().take(80)
    val cleanCategory = category.trim().ifBlank { "General" }.take(30)
    require(cleanTitle.isNotEmpty()) { "Task title cannot be empty" }
    require(points in 1L..500L) { "Points must be between 1 and 500" }

    val docRef = db.collection("users").document(uid).collection("tasks").document()
    val payload =
      mapOf(
        "userId" to uid,
        "title" to cleanTitle,
        "category" to cleanCategory,
        "type" to type.wireValue,
        "points" to points,
        "isActive" to true,
        "sortOrder" to sortOrder.coerceIn(0L, 10000L),
        "createdAt" to FieldValue.serverTimestamp(),
        "updatedAt" to FieldValue.serverTimestamp(),
      )
    try {
      docRef.set(payload).await()
      return docRef.id
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.CREATE, docRef.path)
      throw e
    }
  }

  suspend fun updateTask(
    taskId: String,
    title: String,
    category: String,
    type: TaskType,
    points: Long,
    isActive: Boolean = true,
    sortOrder: Long = 0L,
  ) {
    val uid = requireUserId()
    require(taskId.isNotBlank()) { "Task ID must not be blank" }
    val cleanTitle = title.trim().take(80)
    val cleanCategory = category.trim().ifBlank { "General" }.take(30)
    require(cleanTitle.isNotEmpty()) { "Task title cannot be empty" }
    require(points in 1L..500L) { "Points must be between 1 and 500" }

    val docRef = db.collection("users").document(uid).collection("tasks").document(taskId)
    try {
      docRef
        .update(
          mapOf(
            "title" to cleanTitle,
            "category" to cleanCategory,
            "type" to type.wireValue,
            "points" to points,
            "isActive" to isActive,
            "sortOrder" to sortOrder.coerceIn(0L, 10000L),
            "updatedAt" to FieldValue.serverTimestamp(),
          )
        )
        .await()
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.UPDATE, docRef.path)
      throw e
    }
  }

  suspend fun deleteTask(taskId: String) {
    val uid = requireUserId()
    require(taskId.isNotBlank()) { "Task ID must not be blank" }
    val docRef = db.collection("users").document(uid).collection("tasks").document(taskId)
    try {
      docRef.delete().await()
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.DELETE, docRef.path)
      throw e
    }
  }

  suspend fun toggleTaskForDate(
    dateKey: String,
    taskId: String,
    allTasks: List<HabitTask>,
    existingLogs: List<DailyLog>,
    todayKey: String = LifeScoreAnalytics.todayDateKey(),
  ) {
    val uid = requireUserId()
    val logRef = db.collection("users").document(uid).collection("daily_logs").document(dateKey)
    val userRef = db.collection("users").document(uid)
    val lbRef = db.collection("leaderboard").document(uid)

    val currentLog = existingLogs.firstOrNull { it.dateKey == dateKey }
    val currentIds = currentLog?.completedTaskIds?.toMutableList() ?: mutableListOf()
    if (taskId in currentIds) {
      currentIds.removeAll { it == taskId }
    } else if (currentIds.size < 100) {
      currentIds.add(taskId)
    }

    val calculation = LifeScoreAnalytics.calculateDayBreakdown(allTasks, currentIds.toSet())

    val updatedLogModel =
      DailyLog(
        id = dateKey,
        userId = uid,
        dateKey = dateKey,
        completedTaskIds = currentIds,
        positivePoints = calculation.positivePoints,
        negativePoints = calculation.negativePoints,
        netScore = calculation.netScore,
        positiveCount = calculation.positiveCount,
        negativeCount = calculation.negativeCount,
      )

    val mergedLogs =
      existingLogs.filterNot { it.dateKey == dateKey } + updatedLogModel
    val stats = LifeScoreAnalytics.computeAccountStats(mergedLogs, todayKey)

    try {
      val batch = db.batch()
      if (currentLog == null) {
        batch.set(
          logRef,
          mapOf(
            "userId" to uid,
            "dateKey" to dateKey,
            "completedTaskIds" to currentIds,
            "positivePoints" to calculation.positivePoints,
            "negativePoints" to calculation.negativePoints,
            "netScore" to calculation.netScore,
            "positiveCount" to calculation.positiveCount,
            "negativeCount" to calculation.negativeCount,
            "createdAt" to FieldValue.serverTimestamp(),
            "updatedAt" to FieldValue.serverTimestamp(),
          ),
        )
      } else {
        batch.update(
          logRef,
          mapOf(
            "completedTaskIds" to currentIds,
            "positivePoints" to calculation.positivePoints,
            "negativePoints" to calculation.negativePoints,
            "netScore" to calculation.netScore,
            "positiveCount" to calculation.positiveCount,
            "negativeCount" to calculation.negativeCount,
            "updatedAt" to FieldValue.serverTimestamp(),
          ),
        )
      }

      batch.update(
        userRef,
        mapOf(
          "totalScore" to stats.totalScore,
          "todayScore" to stats.todayScore,
          "currentStreak" to stats.currentStreak,
          "bestDayScore" to stats.bestDayScore,
          "totalPositiveLogged" to stats.totalPositiveLogged,
          "totalNegativeLogged" to stats.totalNegativeLogged,
          "updatedAt" to FieldValue.serverTimestamp(),
        ),
      )

      batch.update(
        lbRef,
        mapOf(
          "totalScore" to stats.totalScore,
          "todayScore" to stats.todayScore,
          "currentStreak" to stats.currentStreak,
          "bestDayScore" to stats.bestDayScore,
          "updatedAt" to FieldValue.serverTimestamp(),
        ),
      )

      batch.commit().await()
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.WRITE, logRef.path)
      throw e
    }
  }

  private data class StarterTask(
    val title: String,
    val category: String,
    val type: TaskType,
    val points: Long,
  )

  private fun defaultStarterTasks(): List<StarterTask> =
    listOf(
      StarterTask("Morning Hydration & Sunlight", "Wellness", TaskType.POSITIVE, 10L),
      StarterTask("30m Focused Deep Work", "Focus", TaskType.POSITIVE, 25L),
      StarterTask("Workout or 8,000 Steps", "Fitness", TaskType.POSITIVE, 20L),
      StarterTask("Read 20 Pages", "Mindset", TaskType.POSITIVE, 15L),
      StarterTask("Clean Meals & No Sugar", "Health", TaskType.POSITIVE, 15L),
      StarterTask("Doomscrolling (>30m)", "Distraction", TaskType.NEGATIVE, 15L),
      StarterTask("Late Night Junk Food", "Health", TaskType.NEGATIVE, 20L),
      StarterTask("Procrastinated Key Priority", "Focus", TaskType.NEGATIVE, 25L),
    )
}
