package com.example.domain

import com.example.data.model.DailyLog
import com.example.data.model.HabitTask
import com.example.data.model.TaskType
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

enum class ProgressPeriod(val label: String) {
  DAILY("Daily"),
  WEEKLY("Weekly"),
  MONTHLY("Monthly"),
}

data class GraphPoint(
  val label: String,
  val fullLabel: String,
  val score: Long,
  val positivePoints: Long,
  val negativePoints: Long,
  val positiveCount: Long,
  val negativeCount: Long,
)

data class PeriodSummary(
  val period: ProgressPeriod,
  val netScore: Long,
  val positivePoints: Long,
  val negativePoints: Long,
  val averageScore: Double,
  val bestScore: Long,
  val lowestScore: Long,
  val positiveDays: Int,
  val totalDays: Int,
  val graphPoints: List<GraphPoint>,
)

data class AggregatedAccountStats(
  val totalScore: Long,
  val todayScore: Long,
  val currentStreak: Long,
  val bestDayScore: Long,
  val totalPositiveLogged: Long,
  val totalNegativeLogged: Long,
)

object LifeScoreAnalytics {

  private const val DATE_FORMAT_PATTERN = "yyyy-MM-dd"

  fun todayDateKey(nowMillis: Long = System.currentTimeMillis()): String {
    val formatter = SimpleDateFormat(DATE_FORMAT_PATTERN, Locale.US)
    return formatter.format(Date(nowMillis))
  }

  fun dateKeyDaysAgo(daysAgo: Int, nowMillis: Long = System.currentTimeMillis()): String {
    val calendar = Calendar.getInstance().apply {
      timeInMillis = nowMillis
      add(Calendar.DAY_OF_YEAR, -daysAgo)
    }
    val formatter = SimpleDateFormat(DATE_FORMAT_PATTERN, Locale.US)
    return formatter.format(calendar.time)
  }

  fun formatDisplayDate(dateKey: String): String {
    val parser = SimpleDateFormat(DATE_FORMAT_PATTERN, Locale.US)
    val display = SimpleDateFormat("EEE, MMM d", Locale.US)
    val parsed = runCatching { parser.parse(dateKey) }.getOrNull() ?: return dateKey
    return display.format(parsed)
  }

  fun shortDayLabel(dateKey: String): String {
    val parser = SimpleDateFormat(DATE_FORMAT_PATTERN, Locale.US)
    val shortFormat = SimpleDateFormat("EEE", Locale.US)
    val parsed = runCatching { parser.parse(dateKey) }.getOrNull() ?: return dateKey
    return shortFormat.format(parsed)
  }

  fun shortMonthDayLabel(dateKey: String): String {
    val parser = SimpleDateFormat(DATE_FORMAT_PATTERN, Locale.US)
    val shortFormat = SimpleDateFormat("M/d", Locale.US)
    val parsed = runCatching { parser.parse(dateKey) }.getOrNull() ?: return dateKey
    return shortFormat.format(parsed)
  }

  fun calculateDayBreakdown(
    tasks: List<HabitTask>,
    completedIds: Set<String>,
  ): DayCalculation {
    var posPoints = 0L
    var negPoints = 0L
    var posCount = 0L
    var negCount = 0L

    for (task in tasks) {
      if (task.id in completedIds) {
        if (task.taskType == TaskType.POSITIVE) {
          posPoints += task.points
          posCount++
        } else {
          negPoints += task.points
          negCount++
        }
      }
    }

    return DayCalculation(
      positivePoints = posPoints,
      negativePoints = negPoints,
      netScore = posPoints - negPoints,
      positiveCount = posCount,
      negativeCount = negCount,
    )
  }

  fun computeAccountStats(
    logs: List<DailyLog>,
    todayKey: String = todayDateKey(),
  ): AggregatedAccountStats {
    if (logs.isEmpty()) {
      return AggregatedAccountStats(0L, 0L, 0L, 0L, 0L, 0L)
    }
    val logByDate = logs.associateBy { it.dateKey }
    val totalScore = logs.sumOf { it.netScore }
    val todayScore = logByDate[todayKey]?.netScore ?: 0L
    val bestDayScore = logs.maxOf { it.netScore }
    val totalPositiveLogged = logs.sumOf { it.positiveCount }
    val totalNegativeLogged = logs.sumOf { it.negativeCount }

    // Streak: consecutive days ending today (or yesterday if today not logged yet) with positive netScore
    var streak = 0L
    var offset = 0
    val todayLog = logByDate[todayKey]
    if (todayLog == null || (todayLog.positiveCount == 0L && todayLog.negativeCount == 0L)) {
      offset = 1
    }
    while (true) {
      val key = dateKeyDaysAgo(offset)
      val dayLog = logByDate[key] ?: break
      if (dayLog.netScore >= 0L && (dayLog.positiveCount > 0L || dayLog.negativeCount > 0L)) {
        streak++
        offset++
      } else {
        break
      }
    }

    return AggregatedAccountStats(
      totalScore = totalScore,
      todayScore = todayScore,
      currentStreak = streak,
      bestDayScore = bestDayScore,
      totalPositiveLogged = totalPositiveLogged,
      totalNegativeLogged = totalNegativeLogged,
    )
  }

  fun buildPeriodSummary(
    period: ProgressPeriod,
    logs: List<DailyLog>,
    tasks: List<HabitTask>,
    todayKey: String = todayDateKey(),
  ): PeriodSummary {
    val logByDate = logs.associateBy { it.dateKey }

    return when (period) {
      ProgressPeriod.DAILY -> {
        val todayLog = logByDate[todayKey]
        val completedSet = todayLog?.completedTaskIds?.toSet() ?: emptySet()
        val completedTasks = tasks.filter { it.id in completedSet }
        val points = mutableListOf<GraphPoint>()
        var runningScore = 0L
        var runningPos = 0L
        var runningNeg = 0L
        var runningPosCount = 0L
        var runningNegCount = 0L

        points.add(
          GraphPoint(
            label = "Start",
            fullLabel = "Day Start (0 pts)",
            score = 0L,
            positivePoints = 0L,
            negativePoints = 0L,
            positiveCount = 0L,
            negativeCount = 0L,
          )
        )

        if (completedTasks.isNotEmpty()) {
          completedTasks.forEachIndexed { idx, task ->
            if (task.taskType == TaskType.POSITIVE) {
              runningPos += task.points
              runningPosCount++
            } else {
              runningNeg += task.points
              runningNegCount++
            }
            runningScore = runningPos - runningNeg
            points.add(
              GraphPoint(
                label = "#${idx + 1}",
                fullLabel = task.title,
                score = runningScore,
                positivePoints = runningPos,
                negativePoints = runningNeg,
                positiveCount = runningPosCount,
                negativeCount = runningNegCount,
              )
            )
          }
        } else if (todayLog != null) {
          points.add(
            GraphPoint(
              label = "Today",
              fullLabel = formatDisplayDate(todayKey),
              score = todayLog.netScore,
              positivePoints = todayLog.positivePoints,
              negativePoints = todayLog.negativePoints,
              positiveCount = todayLog.positiveCount,
              negativeCount = todayLog.negativeCount,
            )
          )
        } else {
          points.add(
            GraphPoint(
              label = "Now",
              fullLabel = formatDisplayDate(todayKey),
              score = 0L,
              positivePoints = 0L,
              negativePoints = 0L,
              positiveCount = 0L,
              negativeCount = 0L,
            )
          )
        }

        val net = todayLog?.netScore ?: 0L
        val pos = todayLog?.positivePoints ?: 0L
        val neg = todayLog?.negativePoints ?: 0L
        val scores = points.map { it.score }

        PeriodSummary(
          period = period,
          netScore = net,
          positivePoints = pos,
          negativePoints = neg,
          averageScore = net.toDouble(),
          bestScore = scores.maxOrNull() ?: 0L,
          lowestScore = scores.minOrNull() ?: 0L,
          positiveDays = if (net > 0L) 1 else 0,
          totalDays = 1,
          graphPoints = points,
        )
      }

      ProgressPeriod.WEEKLY -> {
        buildMultiDaySummary(period = period, dayCount = 7, logByDate = logByDate)
      }

      ProgressPeriod.MONTHLY -> {
        buildMultiDaySummary(period = period, dayCount = 30, logByDate = logByDate)
      }
    }
  }

  private fun buildMultiDaySummary(
    period: ProgressPeriod,
    dayCount: Int,
    logByDate: Map<String, DailyLog>,
  ): PeriodSummary {
    val points = mutableListOf<GraphPoint>()
    var totalNet = 0L
    var totalPos = 0L
    var totalNeg = 0L
    var positiveDays = 0

    for (daysAgo in (dayCount - 1) downTo 0) {
      val key = dateKeyDaysAgo(daysAgo)
      val log = logByDate[key]
      val net = log?.netScore ?: 0L
      val pos = log?.positivePoints ?: 0L
      val neg = log?.negativePoints ?: 0L
      val posC = log?.positiveCount ?: 0L
      val negC = log?.negativeCount ?: 0L

      totalNet += net
      totalPos += pos
      totalNeg += neg
      if (net > 0L) positiveDays++

      val shortLabel = if (dayCount <= 7) shortDayLabel(key) else shortMonthDayLabel(key)
      points.add(
        GraphPoint(
          label = shortLabel,
          fullLabel = formatDisplayDate(key),
          score = net,
          positivePoints = pos,
          negativePoints = neg,
          positiveCount = posC,
          negativeCount = negC,
        )
      )
    }

    val best = points.maxOfOrNull { it.score } ?: 0L
    val low = points.minOfOrNull { it.score } ?: 0L
    return PeriodSummary(
      period = period,
      netScore = totalNet,
      positivePoints = totalPos,
      negativePoints = totalNeg,
      averageScore = totalNet.toDouble() / dayCount.toDouble(),
      bestScore = best,
      lowestScore = low,
      positiveDays = positiveDays,
      totalDays = dayCount,
      graphPoints = points,
    )
  }

  data class DayCalculation(
    val positivePoints: Long,
    val negativePoints: Long,
    val netScore: Long,
    val positiveCount: Long,
    val negativeCount: Long,
  )
}
