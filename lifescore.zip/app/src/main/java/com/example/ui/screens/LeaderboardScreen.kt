package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.EmojiEvents
import androidx.compose.material.icons.rounded.LocalFireDepartment
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.example.data.model.LeaderboardEntry
import com.example.ui.state.UiState
import com.example.ui.theme.EmeraldContainer
import com.example.ui.theme.EmeraldDeep
import com.example.ui.theme.EmeraldMintBorder
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.EmeraldTint
import com.example.ui.theme.GoldAccent
import com.example.ui.theme.GoldTint
import com.example.ui.theme.InkMuted
import com.example.ui.theme.InkPrimary
import com.example.ui.theme.NegativeRose
import com.example.ui.theme.NegativeRoseTint
import com.example.ui.theme.PureWhite
import com.example.ui.theme.SlateBorder
import com.example.ui.theme.SoftSurface

@Composable
fun LeaderboardScreen(
  leaderboardState: UiState<List<LeaderboardEntry>>,
  currentUserId: String,
  modifier: Modifier = Modifier,
) {
  Box(
    modifier = modifier.fillMaxSize().background(PureWhite),
    contentAlignment = Alignment.TopCenter,
  ) {
    when (leaderboardState) {
      UiState.Loading -> {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
          CircularProgressIndicator(color = EmeraldPrimary)
        }
      }
      is UiState.Error -> {
        Box(modifier = Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
          Surface(
            color = NegativeRoseTint,
            shape = RoundedCornerShape(16.dp),
          ) {
            Text(
              text = leaderboardState.message,
              style = MaterialTheme.typography.bodyMedium,
              color = NegativeRose,
              modifier = Modifier.padding(16.dp),
            )
          }
        }
      }
      is UiState.Success -> {
        val entries = leaderboardState.data
        val myRankIndex = entries.indexOfFirst { it.userId == currentUserId }
        val myEntry = entries.getOrNull(myRankIndex)

        LazyColumn(
          modifier = Modifier.widthIn(max = 720.dp).fillMaxSize().testTag("leaderboard_list"),
          contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 12.dp, bottom = 96.dp),
          verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
          item {
            Column {
              Text(
                text = "Global Leaderboard",
                style = MaterialTheme.typography.headlineMedium,
                color = InkPrimary,
              )
              Text(
                text = "Live synchronized LifeScore rankings across all accounts",
                style = MaterialTheme.typography.bodyMedium,
                color = InkMuted,
              )
            }
          }

          if (myEntry != null) {
            item {
              Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = EmeraldTint),
                border = BorderStroke(1.dp, EmeraldMintBorder),
              ) {
                Row(
                  modifier = Modifier.fillMaxWidth().padding(16.dp),
                  horizontalArrangement = Arrangement.SpaceBetween,
                  verticalAlignment = Alignment.CenterVertically,
                ) {
                  Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                      modifier = Modifier.size(44.dp),
                      shape = CircleShape,
                      color = EmeraldPrimary,
                    ) {
                      Box(contentAlignment = Alignment.Center) {
                        Text(
                          text = "#${myRankIndex + 1}",
                          style = MaterialTheme.typography.titleMedium,
                          fontWeight = FontWeight.Bold,
                          color = PureWhite,
                        )
                      }
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                      Text(
                        text = "Your Global Rank",
                        style = MaterialTheme.typography.labelSmall,
                        color = EmeraldDeep,
                      )
                      Text(
                        text = myEntry.displayName,
                        style = MaterialTheme.typography.titleMedium,
                        color = InkPrimary,
                      )
                    }
                  }
                  Column(horizontalAlignment = Alignment.End) {
                    val sign = if (myEntry.totalScore > 0L) "+" else ""
                    Text(
                      text = "$sign${myEntry.totalScore} pts",
                      style = MaterialTheme.typography.titleLarge,
                      fontWeight = FontWeight.Bold,
                      color = if (myEntry.totalScore < 0L) NegativeRose else EmeraldPrimary,
                    )
                    Text(
                      text = "Today ${if (myEntry.todayScore > 0L) "+" else ""}${myEntry.todayScore}",
                      style = MaterialTheme.typography.labelSmall,
                      color = EmeraldDeep,
                    )
                  }
                }
              }
            }
          }

          if (entries.isEmpty()) {
            item {
              Surface(
                modifier = Modifier.fillMaxWidth(),
                color = SoftSurface,
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, SlateBorder),
              ) {
                Text(
                  text = "No leaderboard rankings yet. Start checking tasks to claim #1!",
                  style = MaterialTheme.typography.bodyMedium,
                  color = InkMuted,
                  modifier = Modifier.padding(16.dp),
                )
              }
            }
          } else {
            itemsIndexed(entries, key = { _, entry -> entry.userId }) { index, entry ->
              LeaderboardRowCard(
                rank = index + 1,
                entry = entry,
                isCurrentUser = entry.userId == currentUserId,
              )
            }
          }
        }
      }
    }
  }
}

@Composable
private fun LeaderboardRowCard(
  rank: Int,
  entry: LeaderboardEntry,
  isCurrentUser: Boolean,
) {
  val borderColor = if (isCurrentUser) EmeraldPrimary else SlateBorder
  val bgColor = if (isCurrentUser) EmeraldTint.copy(alpha = 0.45f) else PureWhite

  Surface(
    modifier = Modifier.fillMaxWidth().testTag("leaderboard_row_$rank"),
    color = bgColor,
    shape = RoundedCornerShape(18.dp),
    border = BorderStroke(if (isCurrentUser) 1.5.dp else 1.dp, borderColor),
  ) {
    Row(
      modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 12.dp),
      verticalAlignment = Alignment.CenterVertically,
    ) {
      // Rank badge
      val rankBg =
        when (rank) {
          1 -> GoldTint
          2 -> EmeraldContainer
          3 -> SoftSurface
          else -> SoftSurface
        }
      val rankTint =
        when (rank) {
          1 -> GoldAccent
          2 -> EmeraldDeep
          else -> InkMuted
        }
      Surface(
        modifier = Modifier.size(36.dp),
        shape = CircleShape,
        color = rankBg,
      ) {
        Box(contentAlignment = Alignment.Center) {
          if (rank == 1) {
            Icon(
              imageVector = Icons.Rounded.EmojiEvents,
              contentDescription = "Rank 1",
              tint = GoldAccent,
              modifier = Modifier.size(20.dp),
            )
          } else {
            Text(
              text = "$rank",
              style = MaterialTheme.typography.labelLarge,
              fontWeight = FontWeight.Bold,
              color = rankTint,
            )
          }
        }
      }

      Spacer(modifier = Modifier.width(12.dp))

      // Avatar
      UserAvatarBubble(
        displayName = entry.displayName,
        photoUrl = entry.photoUrl,
        sizeDp = 42,
      )

      Spacer(modifier = Modifier.width(12.dp))

      Column(modifier = Modifier.weight(1f)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Text(
            text = entry.displayName,
            style = MaterialTheme.typography.titleMedium,
            color = InkPrimary,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
          )
          if (isCurrentUser) {
            Spacer(modifier = Modifier.width(6.dp))
            Surface(
              color = EmeraldPrimary,
              shape = RoundedCornerShape(6.dp),
            ) {
              Text(
                text = "YOU",
                style = MaterialTheme.typography.labelSmall,
                color = PureWhite,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
              )
            }
          }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
          Text(
            text = entry.handle,
            style = MaterialTheme.typography.labelSmall,
            color = InkMuted,
          )
          if (entry.currentStreak > 0L) {
            Spacer(modifier = Modifier.width(8.dp))
            Icon(
              imageVector = Icons.Rounded.LocalFireDepartment,
              contentDescription = null,
              tint = EmeraldPrimary,
              modifier = Modifier.size(13.dp),
            )
            Text(
              text = "${entry.currentStreak}d",
              style = MaterialTheme.typography.labelSmall,
              color = EmeraldDeep,
            )
          }
        }
      }

      Spacer(modifier = Modifier.width(8.dp))

      val isNegative = entry.totalScore < 0L
      val sign = if (entry.totalScore > 0L) "+" else ""
      Column(horizontalAlignment = Alignment.End) {
        Text(
          text = "$sign${entry.totalScore}",
          style = MaterialTheme.typography.titleMedium,
          fontWeight = FontWeight.Bold,
          color = if (isNegative) NegativeRose else EmeraldPrimary,
        )
        Text(
          text = "pts",
          style = MaterialTheme.typography.labelSmall,
          color = InkMuted,
        )
      }
    }
  }
}

@Composable
fun UserAvatarBubble(
  displayName: String,
  photoUrl: String,
  sizeDp: Int = 44,
) {
  if (photoUrl.isNotBlank()) {
    AsyncImage(
      model = photoUrl,
      contentDescription = "$displayName avatar",
      modifier = Modifier.size(sizeDp.dp).clip(CircleShape),
      contentScale = ContentScale.Crop,
    )
  } else {
    val initial = displayName.trim().firstOrNull()?.uppercaseChar()?.toString() ?: "L"
    Surface(
      modifier = Modifier.size(sizeDp.dp),
      shape = CircleShape,
      color = EmeraldContainer,
    ) {
      Box(contentAlignment = Alignment.Center) {
        Text(
          text = initial,
          style = MaterialTheme.typography.titleMedium,
          fontWeight = FontWeight.Bold,
          color = EmeraldDeep,
        )
      }
    }
  }
}
