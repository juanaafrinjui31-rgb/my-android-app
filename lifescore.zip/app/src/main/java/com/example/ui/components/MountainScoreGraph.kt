package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.domain.GraphPoint
import com.example.ui.theme.EmeraldBright
import com.example.ui.theme.EmeraldMintBorder
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.EmeraldTint
import com.example.ui.theme.InkMuted
import com.example.ui.theme.InkPrimary
import com.example.ui.theme.InkSecondary
import com.example.ui.theme.NegativeRose
import com.example.ui.theme.NegativeRoseBorder
import com.example.ui.theme.NegativeRoseBright
import com.example.ui.theme.NegativeRoseTint
import com.example.ui.theme.PureWhite
import com.example.ui.theme.SlateBorder
import com.example.ui.theme.SoftSurface
import kotlin.math.abs
import kotlin.math.roundToInt

@Composable
fun MountainScoreGraphCard(
  points: List<GraphPoint>,
  modifier: Modifier = Modifier,
) {
  var selectedIndex by remember(points) { mutableIntStateOf((points.size - 1).coerceAtLeast(0)) }

  LaunchedEffect(points.size) {
    if (points.isNotEmpty() && selectedIndex !in points.indices) {
      selectedIndex = points.lastIndex
    }
  }

  val selectedPoint = points.getOrNull(selectedIndex)
  val maxScore = remember(points) { (points.maxOfOrNull { it.score } ?: 10L).coerceAtLeast(10L) }
  val minScore = remember(points) { (points.minOfOrNull { it.score } ?: 0L).coerceAtMost(0L) }
  // Ensure symmetric-feeling clean bounds around 0 when negative scores exist
  val chartTop = remember(maxScore) { ((maxScore + 9L) / 10L) * 10L }
  val chartBottom = remember(minScore) { if (minScore < 0L) ((minScore - 9L) / 10L) * 10L else 0L }

  Card(
    modifier = modifier.fillMaxWidth().testTag("mountain_graph_card"),
    shape = RoundedCornerShape(22.dp),
    colors = CardDefaults.cardColors(containerColor = PureWhite),
    border = BorderStroke(1.dp, SlateBorder),
    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
  ) {
    Column(modifier = Modifier.fillMaxWidth().padding(18.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Column {
          Text(
            text = "LifeScore Mountain",
            style = MaterialTheme.typography.titleMedium,
            color = InkPrimary,
          )
          Text(
            text = "Tap or drag across the curve to inspect",
            style = MaterialTheme.typography.labelSmall,
            color = InkMuted,
          )
        }

        if (selectedPoint != null) {
          val isNegative = selectedPoint.score < 0L
          Surface(
            color = if (isNegative) NegativeRoseTint else EmeraldTint,
            shape = RoundedCornerShape(12.dp),
            border = BorderStroke(1.dp, if (isNegative) NegativeRoseBorder else EmeraldMintBorder),
          ) {
            val prefix = if (selectedPoint.score > 0L) "+" else ""
            Text(
              text = "$prefix${selectedPoint.score} pts",
              style = MaterialTheme.typography.titleMedium,
              fontWeight = FontWeight.Bold,
              color = if (isNegative) NegativeRose else EmeraldPrimary,
              modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
            )
          }
        }
      }

      if (selectedPoint != null) {
        Spacer(modifier = Modifier.height(12.dp))
        Surface(
          modifier = Modifier.fillMaxWidth(),
          color = SoftSurface,
          shape = RoundedCornerShape(12.dp),
          border = BorderStroke(1.dp, SlateBorder),
        ) {
          Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Text(
              text = selectedPoint.fullLabel,
              style = MaterialTheme.typography.labelLarge,
              color = InkPrimary,
            )
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
              Text(
                text = "+${selectedPoint.positivePoints}",
                style = MaterialTheme.typography.labelLarge,
                color = EmeraldPrimary,
              )
              Text(
                text = "-${selectedPoint.negativePoints}",
                style = MaterialTheme.typography.labelLarge,
                color = NegativeRose,
              )
            }
          }
        }
      }

      Spacer(modifier = Modifier.height(16.dp))

      Row(
        modifier = Modifier.fillMaxWidth().height(210.dp),
        verticalAlignment = Alignment.CenterVertically,
      ) {
        // Y-axis labels column
        Column(
          modifier = Modifier.width(38.dp).height(200.dp),
          verticalArrangement = Arrangement.SpaceBetween,
          horizontalAlignment = Alignment.End,
        ) {
          Text(
            text = "+$chartTop",
            style = MaterialTheme.typography.labelSmall,
            color = InkMuted,
          )
          if (chartBottom < 0L) {
            Text(
              text = "0",
              style = MaterialTheme.typography.labelSmall,
              fontWeight = FontWeight.SemiBold,
              color = InkSecondary,
            )
            Text(
              text = "$chartBottom",
              style = MaterialTheme.typography.labelSmall,
              color = NegativeRose,
            )
          } else {
            Text(
              text = "+${chartTop / 2}",
              style = MaterialTheme.typography.labelSmall,
              color = InkMuted,
            )
            Text(
              text = "0",
              style = MaterialTheme.typography.labelSmall,
              fontWeight = FontWeight.SemiBold,
              color = InkSecondary,
            )
          }
        }

        Spacer(modifier = Modifier.width(8.dp))

        Box(
          modifier =
            Modifier.weight(1f)
              .height(200.dp)
              .pointerInput(points) {
                if (points.isEmpty()) return@pointerInput
                detectTapGestures { offset ->
                  val stepX =
                    if (points.size > 1) size.width.toFloat() / (points.size - 1) else 1f
                  val idx =
                    if (points.size <= 1) 0
                    else (offset.x / stepX).roundToInt().coerceIn(0, points.lastIndex)
                  selectedIndex = idx
                }
              }
              .pointerInput(points) {
                if (points.isEmpty()) return@pointerInput
                detectHorizontalDragGestures { change, _ ->
                  change.consume()
                  val stepX =
                    if (points.size > 1) size.width.toFloat() / (points.size - 1) else 1f
                  val idx =
                    if (points.size <= 1) 0
                    else (change.position.x / stepX).roundToInt().coerceIn(0, points.lastIndex)
                  selectedIndex = idx
                }
              }
        ) {
          Canvas(modifier = Modifier.fillMaxSize()) {
            if (points.isEmpty()) return@Canvas

            val topPad = 12.dp.toPx()
            val bottomPad = 12.dp.toPx()
            val usableHeight = (size.height - topPad - bottomPad).coerceAtLeast(10f)
            val span = (chartTop - chartBottom).toFloat().coerceAtLeast(1f)

            fun scoreToY(score: Float): Float {
              val normalized = (chartTop - score) / span
              return topPad + normalized * usableHeight
            }

            val zeroY = scoreToY(0f)

            // Subtle horizontal grid lines
            val gridLineEffect = PathEffect.dashPathEffect(floatArrayOf(6f, 6f), 0f)
            drawLine(
              color = Color(0xFFE2E8F0),
              start = Offset(0f, topPad),
              end = Offset(size.width, topPad),
              strokeWidth = 1.dp.toPx(),
            )
            if (chartBottom < 0L) {
              drawLine(
                color = Color(0xFFE2E8F0),
                start = Offset(0f, size.height - bottomPad),
                end = Offset(size.width, size.height - bottomPad),
                strokeWidth = 1.dp.toPx(),
              )
            }

            // 0-baseline dashed reference
            drawLine(
              color = Color(0xFF94A3B8),
              start = Offset(0f, zeroY),
              end = Offset(size.width, zeroY),
              strokeWidth = 1.5.dp.toPx(),
              pathEffect = gridLineEffect,
            )

            val coords =
              points.mapIndexed { index, pt ->
                val x =
                  if (points.size == 1) size.width / 2f
                  else (index.toFloat() / (points.size - 1)) * size.width
                val y = scoreToY(pt.score.toFloat())
                Offset(x, y) to pt.score.toFloat()
              }

            // Draw positive mountain fills (above zeroY) and negative valley fills (below zeroY)
            if (coords.size >= 2) {
              for (i in 0 until coords.lastIndex) {
                val (p1, s1) = coords[i]
                val (p2, s2) = coords[i + 1]

                if ((s1 >= 0f && s2 >= 0f) || (s1 <= 0f && s2 <= 0f)) {
                  val isPositiveSeg = s1 >= 0f && s2 >= 0f
                  val fillPath =
                    Path().apply {
                      moveTo(p1.x, zeroY)
                      lineTo(p1.x, p1.y)
                      lineTo(p2.x, p2.y)
                      lineTo(p2.x, zeroY)
                      close()
                    }
                  val brush =
                    if (isPositiveSeg) {
                      Brush.verticalGradient(
                        colors =
                          listOf(
                            EmeraldBright.copy(alpha = 0.34f),
                            EmeraldBright.copy(alpha = 0.04f),
                          ),
                        startY = minOf(p1.y, p2.y),
                        endY = zeroY,
                      )
                    } else {
                      Brush.verticalGradient(
                        colors =
                          listOf(
                            NegativeRoseBright.copy(alpha = 0.04f),
                            NegativeRoseBright.copy(alpha = 0.30f),
                          ),
                        startY = zeroY,
                        endY = maxOf(p1.y, p2.y),
                      )
                    }
                  drawPath(path = fillPath, brush = brush)

                  drawLine(
                    color = if (isPositiveSeg) EmeraldPrimary else NegativeRoseBright,
                    start = p1,
                    end = p2,
                    strokeWidth = 3.dp.toPx(),
                    cap = StrokeCap.Round,
                  )
                } else {
                  // Crosses zero baseline: compute exact zero crossing X
                  val t = abs(s1) / (abs(s1) + abs(s2))
                  val crossX = p1.x + (p2.x - p1.x) * t
                  val crossPt = Offset(crossX, zeroY)

                  // First half (p1 -> crossPt)
                  val firstPositive = s1 > 0f
                  val path1 =
                    Path().apply {
                      moveTo(p1.x, zeroY)
                      lineTo(p1.x, p1.y)
                      lineTo(crossPt.x, crossPt.y)
                      close()
                    }
                  drawPath(
                    path = path1,
                    brush =
                      if (firstPositive) {
                        Brush.verticalGradient(
                          listOf(EmeraldBright.copy(alpha = 0.34f), EmeraldBright.copy(alpha = 0.04f)),
                          startY = p1.y,
                          endY = zeroY,
                        )
                      } else {
                        Brush.verticalGradient(
                          listOf(NegativeRoseBright.copy(alpha = 0.04f), NegativeRoseBright.copy(alpha = 0.30f)),
                          startY = zeroY,
                          endY = p1.y,
                        )
                      },
                  )
                  drawLine(
                    color = if (firstPositive) EmeraldPrimary else NegativeRoseBright,
                    start = p1,
                    end = crossPt,
                    strokeWidth = 3.dp.toPx(),
                    cap = StrokeCap.Round,
                  )

                  // Second half (crossPt -> p2)
                  val secondPositive = s2 > 0f
                  val path2 =
                    Path().apply {
                      moveTo(crossPt.x, zeroY)
                      lineTo(p2.x, p2.y)
                      lineTo(p2.x, zeroY)
                      close()
                    }
                  drawPath(
                    path = path2,
                    brush =
                      if (secondPositive) {
                        Brush.verticalGradient(
                          listOf(EmeraldBright.copy(alpha = 0.34f), EmeraldBright.copy(alpha = 0.04f)),
                          startY = p2.y,
                          endY = zeroY,
                        )
                      } else {
                        Brush.verticalGradient(
                          listOf(NegativeRoseBright.copy(alpha = 0.04f), NegativeRoseBright.copy(alpha = 0.30f)),
                          startY = zeroY,
                          endY = p2.y,
                        )
                      },
                  )
                  drawLine(
                    color = if (secondPositive) EmeraldPrimary else NegativeRoseBright,
                    start = crossPt,
                    end = p2,
                    strokeWidth = 3.dp.toPx(),
                    cap = StrokeCap.Round,
                  )
                }
              }
            }

            // Draw subtle vertices on small series
            if (coords.size <= 14) {
              coords.forEachIndexed { idx, (pt, score) ->
                if (idx != selectedIndex) {
                  drawCircle(
                    color = PureWhite,
                    radius = 3.5.dp.toPx(),
                    center = pt,
                  )
                  drawCircle(
                    color = if (score < 0f) NegativeRoseBright else EmeraldPrimary,
                    radius = 3.5.dp.toPx(),
                    center = pt,
                    style = Stroke(width = 2.dp.toPx(), join = StrokeJoin.Round),
                  )
                }
              }
            }

            // Selected indicator crosshair & glowing node
            coords.getOrNull(selectedIndex)?.let { (selPt, selScore) ->
              val accent = if (selScore < 0f) NegativeRose else EmeraldPrimary
              drawLine(
                color = accent.copy(alpha = 0.35f),
                start = Offset(selPt.x, topPad),
                end = Offset(selPt.x, size.height - bottomPad),
                strokeWidth = 1.5.dp.toPx(),
                pathEffect = PathEffect.dashPathEffect(floatArrayOf(8f, 6f), 0f),
              )
              drawCircle(
                color = accent.copy(alpha = 0.22f),
                radius = 11.dp.toPx(),
                center = selPt,
              )
              drawCircle(
                color = PureWhite,
                radius = 6.dp.toPx(),
                center = selPt,
              )
              drawCircle(
                color = accent,
                radius = 6.dp.toPx(),
                center = selPt,
                style = Stroke(width = 3.dp.toPx()),
              )
            }
          }
        }
      }

      // X-axis tick labels
      if (points.isNotEmpty()) {
        Spacer(modifier = Modifier.height(6.dp))
        Row(
          modifier = Modifier.fillMaxWidth().padding(start = 46.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
        ) {
          val labelIndices =
            when {
              points.size <= 7 -> points.indices.toList()
              else ->
                listOf(
                  0,
                  points.size / 4,
                  points.size / 2,
                  (points.size * 3) / 4,
                  points.lastIndex,
                )
                  .distinct()
            }
          labelIndices.forEach { idx ->
            Text(
              text = points[idx].label,
              style = MaterialTheme.typography.labelSmall,
              color = if (idx == selectedIndex) EmeraldPrimary else InkMuted,
              fontWeight = if (idx == selectedIndex) FontWeight.Bold else FontWeight.Medium,
            )
          }
        }
      }
    }
  }
}
