package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val EmeraldPrimary = Color(0xFF059669)
val EmeraldBright = Color(0xFF10B981)
val EmeraldDeep = Color(0xFF065F46)
val EmeraldDarker = Color(0xFF064E3B)
val EmeraldTint = Color(0xFFECFDF5)
val EmeraldContainer = Color(0xFFD1FAE5)
val EmeraldMintBorder = Color(0xFFA7F3D0)

val PureWhite = Color(0xFFFFFFFF)
val SoftSurface = Color(0xFFF8FAFC)
val SubtleSurface = Color(0xFFF1F5F9)
val SlateBorder = Color(0xFFE2E8F0)

val InkPrimary = Color(0xFF0F172A)
val InkSecondary = Color(0xFF475569)
val InkMuted = Color(0xFF64748B)

val NegativeRose = Color(0xFFDC2626)
val NegativeRoseBright = Color(0xFFEF4444)
val NegativeRoseTint = Color(0xFFFEF2F2)
val NegativeRoseBorder = Color(0xFFFECACA)

val GoldAccent = Color(0xFFF59E0B)
val GoldTint = Color(0xFFFEF3C7)
