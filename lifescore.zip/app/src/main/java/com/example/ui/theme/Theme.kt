package com.example.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp

private val LifeScoreLightColorScheme =
  lightColorScheme(
    primary = EmeraldPrimary,
    onPrimary = PureWhite,
    primaryContainer = EmeraldContainer,
    onPrimaryContainer = EmeraldDarker,
    secondary = EmeraldBright,
    onSecondary = PureWhite,
    secondaryContainer = EmeraldTint,
    onSecondaryContainer = EmeraldDeep,
    tertiary = GoldAccent,
    onTertiary = PureWhite,
    tertiaryContainer = GoldTint,
    onTertiaryContainer = InkPrimary,
    background = PureWhite,
    onBackground = InkPrimary,
    surface = PureWhite,
    onSurface = InkPrimary,
    surfaceVariant = SoftSurface,
    onSurfaceVariant = InkSecondary,
    outline = SlateBorder,
    outlineVariant = SubtleSurface,
    error = NegativeRose,
    onError = PureWhite,
    errorContainer = NegativeRoseTint,
    onErrorContainer = NegativeRose,
  )

private val LifeScoreShapes =
  Shapes(
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(22.dp),
    extraLarge = RoundedCornerShape(28.dp),
  )

@Composable
fun LifeScoreTheme(content: @Composable () -> Unit) {
  MaterialTheme(
    colorScheme = LifeScoreLightColorScheme,
    typography = LifeScoreTypography,
    shapes = LifeScoreShapes,
    content = content,
  )
}
