package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Logout
import androidx.compose.material.icons.rounded.CloudDone
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.UserProfile
import com.example.ui.theme.EmeraldDeep
import com.example.ui.theme.EmeraldMintBorder
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.EmeraldTint
import com.example.ui.theme.InkMuted
import com.example.ui.theme.InkPrimary
import com.example.ui.theme.InkSecondary
import com.example.ui.theme.NegativeRose
import com.example.ui.theme.NegativeRoseBorder
import com.example.ui.theme.PureWhite
import com.example.ui.theme.SlateBorder
import com.example.ui.theme.SoftSurface

@Composable
fun ProfileScreen(
  profile: UserProfile?,
  userEmail: String?,
  onUpdateProfile: (displayName: String, handle: String, bio: String, photoUrl: String) -> Unit,
  onSignOut: () -> Unit,
  modifier: Modifier = Modifier,
) {
  var showEditDialog by remember { mutableStateOf(false) }

  Box(
    modifier = modifier.fillMaxSize().background(PureWhite),
    contentAlignment = Alignment.TopCenter,
  ) {
    LazyColumn(
      modifier = Modifier.widthIn(max = 720.dp).fillMaxSize(),
      contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 12.dp, bottom = 96.dp),
      verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
      item {
        Text(
          text = "Profile",
          style = MaterialTheme.typography.headlineMedium,
          color = InkPrimary,
        )
      }

      // User Identity Card
      item {
        Card(
          modifier = Modifier.fillMaxWidth().testTag("profile_identity_card"),
          shape = RoundedCornerShape(22.dp),
          colors = CardDefaults.cardColors(containerColor = PureWhite),
          border = BorderStroke(1.dp, SlateBorder),
          elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        ) {
          Column(modifier = Modifier.fillMaxWidth().padding(20.dp)) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              verticalAlignment = Alignment.CenterVertically,
            ) {
              UserAvatarBubble(
                displayName = profile?.displayName ?: "Member",
                photoUrl = profile?.photoUrl ?: "",
                sizeDp = 64,
              )
              Spacer(modifier = Modifier.width(16.dp))
              Column(modifier = Modifier.weight(1f)) {
                Text(
                  text = profile?.displayName ?: "LifeScore Member",
                  style = MaterialTheme.typography.titleLarge,
                  color = InkPrimary,
                )
                Text(
                  text = profile?.handle ?: "@member",
                  style = MaterialTheme.typography.labelLarge,
                  color = EmeraldPrimary,
                )
                if (!userEmail.isNullOrBlank()) {
                  Text(
                    text = userEmail,
                    style = MaterialTheme.typography.labelSmall,
                    color = InkMuted,
                  )
                }
              }
            }

            if (!profile?.bio.isNullOrBlank()) {
              Spacer(modifier = Modifier.height(14.dp))
              Text(
                text = profile?.bio ?: "",
                style = MaterialTheme.typography.bodyMedium,
                color = InkSecondary,
              )
            }

            Spacer(modifier = Modifier.height(16.dp))

            OutlinedButton(
              onClick = { showEditDialog = true },
              modifier = Modifier.fillMaxWidth().height(48.dp).testTag("edit_profile_button"),
              shape = RoundedCornerShape(14.dp),
              border = BorderStroke(1.dp, EmeraldPrimary),
            ) {
              Icon(
                imageVector = Icons.Rounded.Edit,
                contentDescription = null,
                tint = EmeraldPrimary,
                modifier = Modifier.size(18.dp),
              )
              Spacer(modifier = Modifier.width(8.dp))
              Text("Edit Profile", color = EmeraldPrimary)
            }
          }
        }
      }

      // Lifetime Account Stats Grid
      item {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
          Text(
            text = "Account Performance",
            style = MaterialTheme.typography.titleMedium,
            color = InkPrimary,
          )
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
          ) {
            val total = profile?.totalScore ?: 0L
            ProfileStatCard(
              label = "Lifetime Score",
              value = "${if (total > 0L) "+" else ""}$total pts",
              isNegative = total < 0L,
              modifier = Modifier.weight(1f),
            )
            val today = profile?.todayScore ?: 0L
            ProfileStatCard(
              label = "Today's Score",
              value = "${if (today > 0L) "+" else ""}$today pts",
              isNegative = today < 0L,
              modifier = Modifier.weight(1f),
            )
          }
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
          ) {
            ProfileStatCard(
              label = "Current Streak",
              value = "${profile?.currentStreak ?: 0L} days",
              isNegative = false,
              modifier = Modifier.weight(1f),
            )
            val best = profile?.bestDayScore ?: 0L
            ProfileStatCard(
              label = "Best Day",
              value = "${if (best > 0L) "+" else ""}$best pts",
              isNegative = best < 0L,
              modifier = Modifier.weight(1f),
            )
          }
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
          ) {
            ProfileStatCard(
              label = "Positive Logged",
              value = "${profile?.totalPositiveLogged ?: 0L}",
              isNegative = false,
              modifier = Modifier.weight(1f),
            )
            ProfileStatCard(
              label = "Negative Logged",
              value = "${profile?.totalNegativeLogged ?: 0L}",
              isNegative = (profile?.totalNegativeLogged ?: 0L) > 0L,
              modifier = Modifier.weight(1f),
            )
          }
        }
      }

      // Sync status & Sign Out
      item {
        Surface(
          modifier = Modifier.fillMaxWidth(),
          color = EmeraldTint,
          shape = RoundedCornerShape(16.dp),
          border = BorderStroke(1.dp, EmeraldMintBorder),
        ) {
          Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Icon(
              imageVector = Icons.Rounded.CloudDone,
              contentDescription = null,
              tint = EmeraldPrimary,
            )
            Spacer(modifier = Modifier.width(12.dp))
            Column {
              Text(
                text = "Private Account Synced",
                style = MaterialTheme.typography.labelLarge,
                color = EmeraldDeep,
              )
              Text(
                text = "Your habits and daily logs are isolated to your Firebase account and synced in real time.",
                style = MaterialTheme.typography.bodyMedium,
                color = InkSecondary,
              )
            }
          }
        }
      }

      item {
        OutlinedButton(
          onClick = onSignOut,
          modifier = Modifier.fillMaxWidth().height(52.dp).testTag("sign_out_button"),
          shape = RoundedCornerShape(14.dp),
          border = BorderStroke(1.dp, NegativeRoseBorder),
        ) {
          Icon(
            imageVector = Icons.AutoMirrored.Rounded.Logout,
            contentDescription = null,
            tint = NegativeRose,
            modifier = Modifier.size(18.dp),
          )
          Spacer(modifier = Modifier.width(8.dp))
          Text("Sign Out", color = NegativeRose, fontWeight = FontWeight.SemiBold)
        }
      }
    }
  }

  if (showEditDialog) {
    EditProfileDialog(
      initialName = profile?.displayName ?: "",
      initialHandle = profile?.handle ?: "@member",
      initialBio = profile?.bio ?: "",
      onDismiss = { showEditDialog = false },
      onSave = { name, handle, bio ->
        onUpdateProfile(name, handle, bio, profile?.photoUrl ?: "")
        showEditDialog = false
      },
    )
  }
}

@Composable
private fun ProfileStatCard(
  label: String,
  value: String,
  isNegative: Boolean,
  modifier: Modifier = Modifier,
) {
  Surface(
    modifier = modifier,
    color = SoftSurface,
    shape = RoundedCornerShape(16.dp),
    border = BorderStroke(1.dp, SlateBorder),
  ) {
    Column(modifier = Modifier.padding(14.dp)) {
      Text(
        text = label,
        style = MaterialTheme.typography.labelSmall,
        color = InkMuted,
      )
      Spacer(modifier = Modifier.height(4.dp))
      Text(
        text = value,
        style = MaterialTheme.typography.titleLarge,
        fontWeight = FontWeight.Bold,
        color = if (isNegative) NegativeRose else EmeraldPrimary,
      )
    }
  }
}

@Composable
private fun EditProfileDialog(
  initialName: String,
  initialHandle: String,
  initialBio: String,
  onDismiss: () -> Unit,
  onSave: (String, String, String) -> Unit,
) {
  var name by remember { mutableStateOf(initialName) }
  var handle by remember { mutableStateOf(initialHandle) }
  var bio by remember { mutableStateOf(initialBio) }
  var error by remember { mutableStateOf<String?>(null) }

  AlertDialog(
    onDismissRequest = onDismiss,
    containerColor = PureWhite,
    title = {
      Text("Edit Profile", style = MaterialTheme.typography.titleLarge, color = InkPrimary)
    },
    text = {
      Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        OutlinedTextField(
          value = name,
          onValueChange = {
            name = it.take(50)
            error = null
          },
          label = { Text("Display Name") },
          singleLine = true,
          colors =
            OutlinedTextFieldDefaults.colors(
              focusedBorderColor = EmeraldPrimary,
              focusedLabelColor = EmeraldPrimary,
            ),
        )
        OutlinedTextField(
          value = handle,
          onValueChange = {
            handle = it.take(30)
            error = null
          },
          label = { Text("Handle") },
          singleLine = true,
          colors =
            OutlinedTextFieldDefaults.colors(
              focusedBorderColor = EmeraldPrimary,
              focusedLabelColor = EmeraldPrimary,
            ),
        )
        OutlinedTextField(
          value = bio,
          onValueChange = { bio = it.take(160) },
          label = { Text("Bio / Goal") },
          maxLines = 3,
          colors =
            OutlinedTextFieldDefaults.colors(
              focusedBorderColor = EmeraldPrimary,
              focusedLabelColor = EmeraldPrimary,
            ),
        )
        if (error != null) {
          Text(text = error!!, style = MaterialTheme.typography.bodyMedium, color = NegativeRose)
        }
      }
    },
    confirmButton = {
      Button(
        onClick = {
          if (name.trim().isEmpty()) {
            error = "Display name is required"
          } else if (handle.trim().length < 2) {
            error = "Handle must be at least 2 characters"
          } else {
            onSave(name.trim(), handle.trim(), bio.trim())
          }
        },
        colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
      ) {
        Text("Save")
      }
    },
    dismissButton = {
      TextButton(onClick = onDismiss) {
        Text("Cancel", color = InkSecondary)
      }
    },
  )
}
