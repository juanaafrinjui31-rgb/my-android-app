package com.example.ui.auth

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AutoGraph
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Leaderboard
import androidx.compose.material.icons.rounded.Shield
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.credentials.CredentialManager
import com.example.R
import com.example.ui.theme.EmeraldBright
import com.example.ui.theme.EmeraldDeep
import com.example.ui.theme.EmeraldMintBorder
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.EmeraldTint
import com.example.ui.theme.InkMuted
import com.example.ui.theme.InkPrimary
import com.example.ui.theme.InkSecondary
import com.example.ui.theme.NegativeRose
import com.example.ui.theme.NegativeRoseBorder
import com.example.ui.theme.NegativeRoseTint
import com.example.ui.theme.PureWhite
import com.example.ui.theme.SlateBorder
import com.example.ui.theme.SoftSurface

@Composable
fun SignInScreen(onAuthSuccess: () -> Unit) {
  val context = LocalContext.current
  val coroutineScope = rememberCoroutineScope()
  val credentialManager = remember(context) { CredentialManager.create(context) }

  var isCheckingSession by remember { mutableStateOf(true) }
  var isSigningIn by remember { mutableStateOf(false) }
  var errorMessage by remember { mutableStateOf<String?>(null) }

  LaunchedEffect(Unit) {
    attemptAutoSignIn(
      context = context,
      credentialManager = credentialManager,
      onAuthSuccess = {
        isCheckingSession = false
        onAuthSuccess()
      },
      onUnauthenticated = { isCheckingSession = false },
      scope = coroutineScope,
    )
  }

  Box(
    modifier =
      Modifier.fillMaxSize()
        .background(PureWhite)
        .statusBarsPadding()
        .navigationBarsPadding(),
    contentAlignment = Alignment.Center,
  ) {
    Column(
      modifier =
        Modifier.widthIn(max = 520.dp)
          .fillMaxSize()
          .verticalScroll(rememberScrollState())
          .padding(horizontal = 24.dp, vertical = 20.dp),
      horizontalAlignment = Alignment.CenterHorizontally,
      verticalArrangement = Arrangement.SpaceBetween,
    ) {
      Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally,
      ) {
        Spacer(modifier = Modifier.height(12.dp))

        // Brand pill
        Surface(
          color = EmeraldTint,
          shape = RoundedCornerShape(999.dp),
          border = BorderStroke(1.dp, EmeraldMintBorder),
        ) {
          Row(
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Box(
              modifier = Modifier.size(8.dp).clip(CircleShape).background(EmeraldPrimary)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = "LIFESCORE • DAILY HABIT LEDGER",
              style = MaterialTheme.typography.labelSmall,
              color = EmeraldDeep,
              fontWeight = FontWeight.Bold,
            )
          }
        }

        Spacer(modifier = Modifier.height(20.dp))

        Text(
          text = "Elevate Every Day.",
          style = MaterialTheme.typography.displayMedium,
          color = InkPrimary,
          textAlign = TextAlign.Center,
        )

        Spacer(modifier = Modifier.height(10.dp))

        Text(
          text = stringResource(R.string.sign_in_tagline),
          style = MaterialTheme.typography.bodyLarge,
          color = InkSecondary,
          textAlign = TextAlign.Center,
        )

        Spacer(modifier = Modifier.height(24.dp))

        // Hero mountain illustration card
        Card(
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(24.dp),
          colors = CardDefaults.cardColors(containerColor = PureWhite),
          border = BorderStroke(1.dp, SlateBorder),
          elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        ) {
          Column(modifier = Modifier.fillMaxWidth()) {
            Image(
              painter = painterResource(id = R.drawable.img_lifescore_hero),
              contentDescription = "LifeScore emerald mountain growth curve",
              modifier = Modifier.fillMaxWidth().height(172.dp),
              contentScale = ContentScale.Crop,
            )
            Row(
              modifier =
                Modifier.fillMaxWidth()
                  .background(SoftSurface)
                  .padding(horizontal = 16.dp, vertical = 12.dp),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically,
            ) {
              Column {
                Text(
                  text = "Positive vs. Negative Balance",
                  style = MaterialTheme.typography.labelLarge,
                  color = InkPrimary,
                )
                Text(
                  text = "Private synced account + global ranks",
                  style = MaterialTheme.typography.labelSmall,
                  color = InkMuted,
                )
              }
              Surface(
                color = EmeraldTint,
                shape = RoundedCornerShape(10.dp),
                border = BorderStroke(1.dp, EmeraldMintBorder),
              ) {
                Text(
                  text = "+45 pts",
                  style = MaterialTheme.typography.labelLarge,
                  color = EmeraldPrimary,
                  modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                )
              }
            }
          }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Feature summary rows
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
          FeatureHighlightRow(
            icon = Icons.Rounded.CheckCircle,
            title = "Daily Positive & Negative Checklist",
            subtitle = "Automatic net score calculation as you log habits.",
          )
          FeatureHighlightRow(
            icon = Icons.Rounded.AutoGraph,
            title = "Interactive Mountain Progress Graph",
            subtitle = "Inspect daily, weekly & monthly peaks and negative dips.",
          )
          FeatureHighlightRow(
            icon = Icons.Rounded.Leaderboard,
            title = "Personal Profile & Global Leaderboard",
            subtitle = "Individual cloud-synced accounts & live rankings.",
          )
        }
      }

      Column(
        modifier = Modifier.fillMaxWidth().padding(top = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
      ) {
        if (errorMessage != null) {
          Surface(
            modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
            color = NegativeRoseTint,
            shape = RoundedCornerShape(14.dp),
            border = BorderStroke(1.dp, NegativeRoseBorder),
          ) {
            Text(
              text = errorMessage!!,
              style = MaterialTheme.typography.bodyMedium,
              color = NegativeRose,
              modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
            )
          }
        }

        Button(
          onClick = {
            errorMessage = null
            isSigningIn = true
            onGoogleSignInClicked(
              context = context,
              credentialManager = credentialManager,
              onAuthSuccess = {
                isSigningIn = false
                onAuthSuccess()
              },
              onAuthError = { msg ->
                isSigningIn = false
                errorMessage = msg
              },
              scope = coroutineScope,
              onAuthCancelled = { isSigningIn = false },
            )
          },
          enabled = !isSigningIn && !isCheckingSession,
          modifier =
            Modifier.fillMaxWidth().height(56.dp).testTag("google_sign_in_button"),
          shape = RoundedCornerShape(16.dp),
          colors =
            ButtonDefaults.buttonColors(
              containerColor = EmeraldPrimary,
              contentColor = PureWhite,
              disabledContainerColor = EmeraldBright.copy(alpha = 0.5f),
            ),
        ) {
          if (isSigningIn || isCheckingSession) {
            CircularProgressIndicator(
              modifier = Modifier.size(22.dp),
              color = PureWhite,
              strokeWidth = 2.5.dp,
            )
            Spacer(modifier = Modifier.width(12.dp))
            Text(
              text = if (isCheckingSession) "Checking session..." else "Signing in...",
              style = MaterialTheme.typography.titleMedium,
            )
          } else {
            Icon(
              imageVector = Icons.Rounded.Shield,
              contentDescription = null,
              modifier = Modifier.size(20.dp),
            )
            Spacer(modifier = Modifier.width(10.dp))
            Text(
              text = stringResource(R.string.sign_in_google),
              style = MaterialTheme.typography.titleMedium,
            )
          }
        }

        Spacer(modifier = Modifier.height(10.dp))

        Text(
          text = "Your tasks and daily logs remain private to your account.",
          style = MaterialTheme.typography.labelSmall,
          color = InkMuted,
          textAlign = TextAlign.Center,
        )
      }
    }
  }
}

@Composable
private fun FeatureHighlightRow(
  icon: ImageVector,
  title: String,
  subtitle: String,
) {
  Surface(
    modifier = Modifier.fillMaxWidth(),
    color = SoftSurface,
    shape = RoundedCornerShape(14.dp),
    border = BorderStroke(1.dp, SlateBorder),
  ) {
    Row(
      modifier = Modifier.padding(horizontal = 14.dp, vertical = 12.dp),
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Surface(
        modifier = Modifier.size(38.dp),
        color = EmeraldTint,
        shape = RoundedCornerShape(10.dp),
      ) {
        Box(contentAlignment = Alignment.Center) {
          Icon(
            imageVector = icon,
            contentDescription = null,
            tint = EmeraldPrimary,
            modifier = Modifier.size(20.dp),
          )
        }
      }
      Spacer(modifier = Modifier.width(12.dp))
      Column {
        Text(
          text = title,
          style = MaterialTheme.typography.labelLarge,
          color = InkPrimary,
        )
        Text(
          text = subtitle,
          style = MaterialTheme.typography.bodyMedium,
          color = InkMuted,
        )
      }
    }
  }
}
