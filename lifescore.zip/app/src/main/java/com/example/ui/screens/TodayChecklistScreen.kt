package com.example.ui.screens

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.rounded.KeyboardArrowRight
import androidx.compose.material.icons.automirrored.rounded.TrendingDown
import androidx.compose.material.icons.automirrored.rounded.TrendingUp
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.LocalFireDepartment
import androidx.compose.material.icons.rounded.Remove
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.model.HabitTask
import com.example.data.model.TaskType
import com.example.domain.LifeScoreAnalytics
import com.example.ui.state.DashboardSnapshot
import com.example.ui.state.TaskFilter
import com.example.ui.theme.EmeraldBright
import com.example.ui.theme.EmeraldContainer
import com.example.ui.theme.EmeraldDarker
import com.example.ui.theme.EmeraldDeep
import com.example.ui.theme.EmeraldMintBorder
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.EmeraldTint
import com.example.ui.theme.InkMuted
import com.example.ui.theme.InkPrimary
import com.example.ui.theme.InkSecondary
import com.example.ui.theme.NegativeRose
import com.example.ui.theme.NegativeRoseBorder
import com.example.ui.theme.NegativeRoseBright
import com.example.ui.theme.NegativeRoseTint
import com.example.ui.theme.PureWhite
import com.example.ui.theme.SlateBorder
import com.example.ui.theme.SoftSurface

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TodayChecklistScreen(
  snapshot: DashboardSnapshot,
  onToggleTask: (String) -> Unit,
  onShiftDate: (Int) -> Unit,
  onSelectFilter: (TaskFilter) -> Unit,
  onAddTask: (String, String, TaskType, Long) -> Unit,
  onUpdateTask: (HabitTask, String, String, TaskType, Long) -> Unit,
  onDeleteTask: (HabitTask) -> Unit,
  modifier: Modifier = Modifier,
) {
  var showTaskSheet by remember { mutableStateOf(false) }
  var editingTask by remember { mutableStateOf<HabitTask?>(null) }
  var deletingTask by remember { mutableStateOf<HabitTask?>(null) }

  val todayKey = remember { LifeScoreAnalytics.todayDateKey() }
  val isToday = snapshot.selectedDateKey == todayKey
  val selectedLog = snapshot.dailyLogs.firstOrNull { it.dateKey == snapshot.selectedDateKey }
  val completedIds = selectedLog?.completedTaskIds?.toSet() ?: emptySet()

  val liveCalc =
    remember(snapshot.tasks, completedIds) {
      LifeScoreAnalytics.calculateDayBreakdown(snapshot.tasks, completedIds)
    }

  val filteredTasks =
    remember(snapshot.tasks, snapshot.taskFilter) {
      when (snapshot.taskFilter) {
        TaskFilter.ALL -> snapshot.tasks
        TaskFilter.POSITIVE -> snapshot.tasks.filter { it.taskType == TaskType.POSITIVE }
        TaskFilter.NEGATIVE -> snapshot.tasks.filter { it.taskType == TaskType.NEGATIVE }
      }
    }

  val positiveTasks = filteredTasks.filter { it.taskType == TaskType.POSITIVE }
  val negativeTasks = filteredTasks.filter { it.taskType == TaskType.NEGATIVE }

  Box(
    modifier = modifier.fillMaxSize().background(PureWhite),
    contentAlignment = Alignment.TopCenter,
  ) {
    LazyColumn(
      modifier = Modifier.widthIn(max = 720.dp).fillMaxSize(),
      contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 12.dp, bottom = 96.dp),
      verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
      // Header + Date Navigation
      item {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Column {
            Text(
              text = "LifeScore",
              style = MaterialTheme.typography.headlineMedium,
              color = InkPrimary,
            )
            Text(
              text =
                if (isToday) "Today • ${LifeScoreAnalytics.formatDisplayDate(snapshot.selectedDateKey)}"
                else LifeScoreAnalytics.formatDisplayDate(snapshot.selectedDateKey),
              style = MaterialTheme.typography.bodyMedium,
              color = InkMuted,
            )
          }

          Row(verticalAlignment = Alignment.CenterVertically) {
            Surface(
              shape = RoundedCornerShape(12.dp),
              color = SoftSurface,
              border = BorderStroke(1.dp, SlateBorder),
            ) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(
                  onClick = { onShiftDate(-1) },
                  modifier = Modifier.size(48.dp).testTag("prev_day_button"),
                ) {
                  Icon(
                    imageVector = Icons.AutoMirrored.Rounded.KeyboardArrowLeft,
                    contentDescription = "Previous day",
                    tint = InkPrimary,
                  )
                }
                IconButton(
                  onClick = { onShiftDate(1) },
                  enabled = !isToday,
                  modifier = Modifier.size(48.dp).testTag("next_day_button"),
                ) {
                  Icon(
                    imageVector = Icons.AutoMirrored.Rounded.KeyboardArrowRight,
                    contentDescription = "Next day",
                    tint = if (isToday) InkMuted.copy(alpha = 0.35f) else InkPrimary,
                  )
                }
              }
            }
          }
        }
      }

      // Hero Daily Score Card
      item {
        val net = liveCalc.netScore
        val isNegative = net < 0L
        val gradientColors =
          if (isNegative) listOf(NegativeRose, NegativeRoseBright)
          else listOf(EmeraldDeep, EmeraldPrimary)

        Card(
          modifier = Modifier.fillMaxWidth().testTag("daily_score_hero_card"),
          shape = RoundedCornerShape(24.dp),
          colors = CardDefaults.cardColors(containerColor = EmeraldPrimary),
          elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
        ) {
          Column(
            modifier =
              Modifier.fillMaxWidth()
                .background(Brush.linearGradient(gradientColors))
                .padding(20.dp)
          ) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically,
            ) {
              Text(
                text = if (isToday) "TODAY'S LIFESCORE" else "DAY SCORE",
                style = MaterialTheme.typography.labelSmall,
                color = PureWhite.copy(alpha = 0.85f),
                fontWeight = FontWeight.Bold,
              )

              Surface(
                color = PureWhite.copy(alpha = 0.18f),
                shape = RoundedCornerShape(999.dp),
              ) {
                Row(
                  modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                  verticalAlignment = Alignment.CenterVertically,
                ) {
                  Icon(
                    imageVector = Icons.Rounded.LocalFireDepartment,
                    contentDescription = null,
                    tint = PureWhite,
                    modifier = Modifier.size(14.dp),
                  )
                  Spacer(modifier = Modifier.width(4.dp))
                  Text(
                    text = "${snapshot.profile?.currentStreak ?: 0L}d streak",
                    style = MaterialTheme.typography.labelSmall,
                    color = PureWhite,
                    fontWeight = FontWeight.SemiBold,
                  )
                }
              }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(
              verticalAlignment = Alignment.Bottom,
              horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
              val scorePrefix = if (net > 0L) "+" else ""
              Text(
                text = "$scorePrefix$net",
                style = MaterialTheme.typography.displayLarge,
                color = PureWhite,
              )
              Text(
                text = "pts",
                style = MaterialTheme.typography.titleMedium,
                color = PureWhite.copy(alpha = 0.85f),
                modifier = Modifier.padding(bottom = 8.dp),
              )
            }

            Spacer(modifier = Modifier.height(14.dp))

            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
              HeroBreakdownPill(
                label = "Positive",
                value = "+${liveCalc.positivePoints}",
                sub = "${liveCalc.positiveCount} done",
                modifier = Modifier.weight(1f),
              )
              HeroBreakdownPill(
                label = "Negative",
                value = "-${liveCalc.negativePoints}",
                sub = "${liveCalc.negativeCount} logged",
                modifier = Modifier.weight(1f),
              )
              HeroBreakdownPill(
                label = "Lifetime",
                value = formatSigned(snapshot.profile?.totalScore ?: 0L),
                sub = "Total",
                modifier = Modifier.weight(1f),
              )
            }
          }
        }
      }

      // Filter Chips + Add Task Button
      item {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            TaskFilter.entries.forEach { filter ->
              val selected = snapshot.taskFilter == filter
              FilterChip(
                selected = selected,
                onClick = { onSelectFilter(filter) },
                label = {
                  Text(
                    text = filter.label,
                    style = MaterialTheme.typography.labelLarge,
                  )
                },
                colors =
                  FilterChipDefaults.filterChipColors(
                    selectedContainerColor = EmeraldTint,
                    selectedLabelColor = EmeraldDeep,
                    containerColor = PureWhite,
                    labelColor = InkSecondary,
                  ),
                border =
                  FilterChipDefaults.filterChipBorder(
                    enabled = true,
                    selected = selected,
                    borderColor = SlateBorder,
                    selectedBorderColor = EmeraldPrimary,
                  ),
              )
            }
          }

          IconButton(
            onClick = {
              editingTask = null
              showTaskSheet = true
            },
            modifier = Modifier.minimumInteractiveComponentSize().testTag("header_add_task_button"),
          ) {
            Surface(
              color = EmeraldPrimary,
              shape = CircleShape,
              modifier = Modifier.size(36.dp),
            ) {
              Box(contentAlignment = Alignment.Center) {
                Icon(
                  imageVector = Icons.Rounded.Add,
                  contentDescription = "Add task",
                  tint = PureWhite,
                  modifier = Modifier.size(20.dp),
                )
              }
            }
          }
        }
      }

      if (snapshot.tasks.isEmpty()) {
        item {
          EmptyTasksCard(
            onAddClick = {
              editingTask = null
              showTaskSheet = true
            }
          )
        }
      } else {
        if (positiveTasks.isNotEmpty()) {
          item {
            SectionHeaderRow(
              title = "Positive Habits",
              badgeText = "+${positiveTasks.count { it.id in completedIds }}/${positiveTasks.size}",
              isNegative = false,
            )
          }
          items(positiveTasks, key = { it.id }) { task ->
            HabitTaskRow(
              task = task,
              isCompleted = task.id in completedIds,
              onToggle = { onToggleTask(task.id) },
              onEdit = {
                editingTask = task
                showTaskSheet = true
              },
              onDelete = { deletingTask = task },
            )
          }
        }

        if (negativeTasks.isNotEmpty()) {
          item {
            Spacer(modifier = Modifier.height(4.dp))
            SectionHeaderRow(
              title = "Negative Habits",
              badgeText = "${negativeTasks.count { it.id in completedIds }} logged",
              isNegative = true,
            )
          }
          items(negativeTasks, key = { it.id }) { task ->
            HabitTaskRow(
              task = task,
              isCompleted = task.id in completedIds,
              onToggle = { onToggleTask(task.id) },
              onEdit = {
                editingTask = task
                showTaskSheet = true
              },
              onDelete = { deletingTask = task },
            )
          }
        }
      }
    }

    FloatingActionButton(
      onClick = {
        editingTask = null
        showTaskSheet = true
      },
      containerColor = EmeraldPrimary,
      contentColor = PureWhite,
      shape = RoundedCornerShape(18.dp),
      modifier =
        Modifier.align(Alignment.BottomEnd)
          .padding(end = 20.dp, bottom = 20.dp)
          .testTag("add_task_fab"),
    ) {
      Icon(
        imageVector = Icons.Rounded.Add,
        contentDescription = "Add habit task",
      )
    }
  }

  if (showTaskSheet) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    ModalBottomSheet(
      onDismissRequest = { showTaskSheet = false },
      sheetState = sheetState,
      containerColor = PureWhite,
    ) {
      TaskEditorSheetContent(
        initialTask = editingTask,
        onDismiss = { showTaskSheet = false },
        onSave = { title, category, type, points ->
          val existing = editingTask
          if (existing == null) {
            onAddTask(title, category, type, points)
          } else {
            onUpdateTask(existing, title, category, type, points)
          }
          showTaskSheet = false
        },
      )
    }
  }

  deletingTask?.let { target ->
    AlertDialog(
      onDismissRequest = { deletingTask = null },
      containerColor = PureWhite,
      title = {
        Text(
          text = "Delete Task?",
          style = MaterialTheme.typography.titleLarge,
          color = InkPrimary,
        )
      },
      text = {
        Text(
          text = "Remove \"${target.title}\" from your daily checklist? Past daily score totals are preserved.",
          style = MaterialTheme.typography.bodyMedium,
          color = InkSecondary,
        )
      },
      confirmButton = {
        Button(
          onClick = {
            onDeleteTask(target)
            deletingTask = null
          },
          colors = ButtonDefaults.buttonColors(containerColor = NegativeRose),
        ) {
          Text("Delete")
        }
      },
      dismissButton = {
        TextButton(onClick = { deletingTask = null }) {
          Text("Cancel", color = InkSecondary)
        }
      },
    )
  }
}

@Composable
private fun HeroBreakdownPill(
  label: String,
  value: String,
  sub: String,
  modifier: Modifier = Modifier,
) {
  Surface(
    modifier = modifier,
    color = PureWhite.copy(alpha = 0.16f),
    shape = RoundedCornerShape(14.dp),
  ) {
    Column(modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp)) {
      Text(
        text = label,
        style = MaterialTheme.typography.labelSmall,
        color = PureWhite.copy(alpha = 0.8f),
      )
      Text(
        text = value,
        style = MaterialTheme.typography.titleMedium,
        fontWeight = FontWeight.Bold,
        color = PureWhite,
      )
      Text(
        text = sub,
        style = MaterialTheme.typography.labelSmall,
        color = PureWhite.copy(alpha = 0.78f),
      )
    }
  }
}

@Composable
private fun SectionHeaderRow(
  title: String,
  badgeText: String,
  isNegative: Boolean,
) {
  Row(
    modifier = Modifier.fillMaxWidth().padding(top = 4.dp),
    horizontalArrangement = Arrangement.SpaceBetween,
    verticalAlignment = Alignment.CenterVertically,
  ) {
    Row(verticalAlignment = Alignment.CenterVertically) {
      Icon(
        imageVector =
          if (isNegative) Icons.AutoMirrored.Rounded.TrendingDown
          else Icons.AutoMirrored.Rounded.TrendingUp,
        contentDescription = null,
        tint = if (isNegative) NegativeRose else EmeraldPrimary,
        modifier = Modifier.size(18.dp),
      )
      Spacer(modifier = Modifier.width(6.dp))
      Text(
        text = title,
        style = MaterialTheme.typography.titleMedium,
        color = InkPrimary,
      )
    }

    Surface(
      color = if (isNegative) NegativeRoseTint else EmeraldTint,
      shape = RoundedCornerShape(999.dp),
    ) {
      Text(
        text = badgeText,
        style = MaterialTheme.typography.labelSmall,
        color = if (isNegative) NegativeRose else EmeraldDeep,
        fontWeight = FontWeight.SemiBold,
        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
      )
    }
  }
}

@Composable
private fun HabitTaskRow(
  task: HabitTask,
  isCompleted: Boolean,
  onToggle: () -> Unit,
  onEdit: () -> Unit,
  onDelete: () -> Unit,
) {
  val isNegative = task.taskType == TaskType.NEGATIVE
  val containerColor by
    animateColorAsState(
      targetValue =
        when {
          isCompleted && isNegative -> NegativeRoseTint
          isCompleted -> EmeraldTint
          else -> PureWhite
        },
      label = "taskBg",
    )
  val borderColor =
    when {
      isCompleted && isNegative -> NegativeRoseBorder
      isCompleted -> EmeraldMintBorder
      else -> SlateBorder
    }

  Surface(
    modifier =
      Modifier.fillMaxWidth()
        .clip(RoundedCornerShape(16.dp))
        .clickable(onClick = onToggle)
        .testTag("task_row_${task.id}"),
    color = containerColor,
    shape = RoundedCornerShape(16.dp),
    border = BorderStroke(1.dp, borderColor),
  ) {
    Row(
      modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 12.dp),
      verticalAlignment = Alignment.CenterVertically,
    ) {
      // Tactile check indicator
      val checkBg =
        when {
          isCompleted && isNegative -> NegativeRose
          isCompleted -> EmeraldPrimary
          else -> PureWhite
        }
      val checkBorder =
        when {
          isCompleted -> checkBg
          isNegative -> NegativeRose.copy(alpha = 0.45f)
          else -> EmeraldPrimary.copy(alpha = 0.5f)
        }
      Surface(
        modifier = Modifier.size(28.dp),
        shape = RoundedCornerShape(9.dp),
        color = checkBg,
        border = BorderStroke(2.dp, checkBorder),
      ) {
        Box(contentAlignment = Alignment.Center) {
          if (isCompleted) {
            Icon(
              imageVector = if (isNegative) Icons.Rounded.Remove else Icons.Rounded.Check,
              contentDescription = if (isNegative) "Logged negative habit" else "Completed task",
              tint = PureWhite,
              modifier = Modifier.size(16.dp),
            )
          }
        }
      }

      Spacer(modifier = Modifier.width(12.dp))

      Column(modifier = Modifier.weight(1f)) {
        Text(
          text = task.title,
          style = MaterialTheme.typography.titleMedium,
          color = InkPrimary,
          maxLines = 2,
          overflow = TextOverflow.Ellipsis,
        )
        Spacer(modifier = Modifier.height(2.dp))
        Text(
          text = task.category,
          style = MaterialTheme.typography.labelSmall,
          color = InkMuted,
        )
      }

      Spacer(modifier = Modifier.width(8.dp))

      val badgeText = if (isNegative) "-${task.points}" else "+${task.points}"
      Surface(
        color = if (isNegative) NegativeRoseTint else EmeraldContainer,
        shape = RoundedCornerShape(10.dp),
        border =
          BorderStroke(
            1.dp,
            if (isNegative) NegativeRoseBorder else EmeraldMintBorder,
          ),
      ) {
        Text(
          text = badgeText,
          style = MaterialTheme.typography.labelLarge,
          fontWeight = FontWeight.Bold,
          color = if (isNegative) NegativeRose else EmeraldDarker,
          modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
        )
      }

      IconButton(
        onClick = onEdit,
        modifier = Modifier.size(40.dp).testTag("edit_task_${task.id}"),
      ) {
        Icon(
          imageVector = Icons.Rounded.Edit,
          contentDescription = "Edit task",
          tint = InkMuted,
          modifier = Modifier.size(18.dp),
        )
      }

      IconButton(
        onClick = onDelete,
        modifier = Modifier.size(40.dp).testTag("delete_task_${task.id}"),
      ) {
        Icon(
          imageVector = Icons.Rounded.DeleteOutline,
          contentDescription = "Delete task",
          tint = InkMuted,
          modifier = Modifier.size(18.dp),
        )
      }
    }
  }
}

@Composable
private fun EmptyTasksCard(onAddClick: () -> Unit) {
  Card(
    modifier = Modifier.fillMaxWidth(),
    shape = RoundedCornerShape(20.dp),
    colors = CardDefaults.cardColors(containerColor = SoftSurface),
    border = BorderStroke(1.dp, SlateBorder),
  ) {
    Column(
      modifier = Modifier.fillMaxWidth().padding(24.dp),
      horizontalAlignment = Alignment.CenterHorizontally,
    ) {
      Text(
        text = "No habits yet",
        style = MaterialTheme.typography.titleLarge,
        color = InkPrimary,
      )
      Spacer(modifier = Modifier.height(6.dp))
      Text(
        text = "Create positive habits (+pts) and negative pitfalls (-pts) to track your daily LifeScore.",
        style = MaterialTheme.typography.bodyMedium,
        color = InkMuted,
      )
      Spacer(modifier = Modifier.height(16.dp))
      Button(
        onClick = onAddClick,
        colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
        shape = RoundedCornerShape(14.dp),
      ) {
        Icon(Icons.Rounded.Add, contentDescription = null)
        Spacer(modifier = Modifier.width(6.dp))
        Text("Create First Task")
      }
    }
  }
}

@Composable
private fun TaskEditorSheetContent(
  initialTask: HabitTask?,
  onDismiss: () -> Unit,
  onSave: (String, String, TaskType, Long) -> Unit,
) {
  var title by remember(initialTask) { mutableStateOf(initialTask?.title ?: "") }
  var category by remember(initialTask) { mutableStateOf(initialTask?.category ?: "Wellness") }
  var taskType by remember(initialTask) {
    mutableStateOf(initialTask?.taskType ?: TaskType.POSITIVE)
  }
  var pointsText by remember(initialTask) {
    mutableStateOf((initialTask?.points ?: 15L).toString())
  }
  var validationError by remember { mutableStateOf<String?>(null) }

  val categoryOptions =
    if (taskType == TaskType.POSITIVE) {
      listOf("Wellness", "Focus", "Fitness", "Mindset", "Health")
    } else {
      listOf("Distraction", "Health", "Focus", "Sleep", "Fitness")
    }

  Column(
    modifier = Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 12.dp),
    verticalArrangement = Arrangement.spacedBy(14.dp),
  ) {
    Text(
      text = if (initialTask == null) "New Checklist Task" else "Edit Task",
      style = MaterialTheme.typography.headlineMedium,
      color = InkPrimary,
    )

    // Positive vs Negative toggle
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.spacedBy(10.dp),
    ) {
      val posSelected = taskType == TaskType.POSITIVE
      OutlinedButton(
        onClick = {
          taskType = TaskType.POSITIVE
          if (category == "Distraction") category = "Wellness"
        },
        modifier = Modifier.weight(1f).height(48.dp).testTag("type_positive_button"),
        shape = RoundedCornerShape(14.dp),
        colors =
          ButtonDefaults.outlinedButtonColors(
            containerColor = if (posSelected) EmeraldTint else PureWhite,
            contentColor = if (posSelected) EmeraldDeep else InkSecondary,
          ),
        border = BorderStroke(1.5.dp, if (posSelected) EmeraldPrimary else SlateBorder),
      ) {
        Icon(Icons.AutoMirrored.Rounded.TrendingUp, contentDescription = null, modifier = Modifier.size(18.dp))
        Spacer(modifier = Modifier.width(6.dp))
        Text("Positive (+)")
      }

      val negSelected = taskType == TaskType.NEGATIVE
      OutlinedButton(
        onClick = {
          taskType = TaskType.NEGATIVE
          if (category == "Wellness") category = "Distraction"
        },
        modifier = Modifier.weight(1f).height(48.dp).testTag("type_negative_button"),
        shape = RoundedCornerShape(14.dp),
        colors =
          ButtonDefaults.outlinedButtonColors(
            containerColor = if (negSelected) NegativeRoseTint else PureWhite,
            contentColor = if (negSelected) NegativeRose else InkSecondary,
          ),
        border = BorderStroke(1.5.dp, if (negSelected) NegativeRose else SlateBorder),
      ) {
        Icon(Icons.AutoMirrored.Rounded.TrendingDown, contentDescription = null, modifier = Modifier.size(18.dp))
        Spacer(modifier = Modifier.width(6.dp))
        Text("Negative (-)")
      }
    }

    OutlinedTextField(
      value = title,
      onValueChange = {
        title = it.take(80)
        validationError = null
      },
      label = { Text("Task Name") },
      placeholder = {
        Text(
          if (taskType == TaskType.POSITIVE) "e.g., 30m Morning Run"
          else "e.g., Late-night scrolling"
        )
      },
      singleLine = true,
      modifier = Modifier.fillMaxWidth().testTag("task_title_input"),
      colors =
        OutlinedTextFieldDefaults.colors(
          focusedBorderColor = EmeraldPrimary,
          focusedLabelColor = EmeraldPrimary,
        ),
    )

    OutlinedTextField(
      value = pointsText,
      onValueChange = { input ->
        pointsText = input.filter { it.isDigit() }.take(3)
        validationError = null
      },
      label = {
        Text(if (taskType == TaskType.POSITIVE) "Points Added (+)" else "Points Deducted (-)")
      },
      keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
      singleLine = true,
      modifier = Modifier.fillMaxWidth().testTag("task_points_input"),
      colors =
        OutlinedTextFieldDefaults.colors(
          focusedBorderColor = EmeraldPrimary,
          focusedLabelColor = EmeraldPrimary,
        ),
    )

    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
      Text(
        text = "Category",
        style = MaterialTheme.typography.labelLarge,
        color = InkSecondary,
      )
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
      ) {
        categoryOptions.take(4).forEach { cat ->
          val selected = category == cat
          FilterChip(
            selected = selected,
            onClick = { category = cat },
            label = { Text(cat, style = MaterialTheme.typography.labelSmall) },
            colors =
              FilterChipDefaults.filterChipColors(
                selectedContainerColor = EmeraldTint,
                selectedLabelColor = EmeraldDeep,
              ),
          )
        }
      }
    }

    if (validationError != null) {
      Text(
        text = validationError!!,
        style = MaterialTheme.typography.bodyMedium,
        color = NegativeRose,
      )
    }

    Row(
      modifier = Modifier.fillMaxWidth().padding(top = 4.dp, bottom = 16.dp),
      horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
      OutlinedButton(
        onClick = onDismiss,
        modifier = Modifier.weight(1f).height(50.dp),
        shape = RoundedCornerShape(14.dp),
      ) {
        Text("Cancel", color = InkSecondary)
      }
      Button(
        onClick = {
          val pts = pointsText.toLongOrNull()
          when {
            title.trim().isEmpty() -> validationError = "Please enter a task name."
            pts == null || pts !in 1L..500L ->
              validationError = "Points must be between 1 and 500."
            else -> onSave(title.trim(), category, taskType, pts)
          }
        },
        modifier = Modifier.weight(1f).height(50.dp).testTag("save_task_button"),
        shape = RoundedCornerShape(14.dp),
        colors =
          ButtonDefaults.buttonColors(
            containerColor = if (taskType == TaskType.POSITIVE) EmeraldPrimary else NegativeRose,
          ),
      ) {
        Text("Save Task")
      }
    }
  }
}

private fun formatSigned(value: Long): String =
  if (value > 0L) "+$value" else value.toString()
