package com.example.ui.state

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.DailyLog
import com.example.data.model.HabitTask
import com.example.data.model.LeaderboardEntry
import com.example.data.model.TaskType
import com.example.data.model.UserProfile
import com.example.data.repository.LifeScoreRepository
import com.example.domain.LifeScoreAnalytics
import com.example.domain.PeriodSummary
import com.example.domain.ProgressPeriod
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

sealed interface UiState<out T> {
  data object Loading : UiState<Nothing>

  data class Success<T>(val data: T) : UiState<T>

  data class Error(val message: String) : UiState<Nothing>
}

enum class TaskFilter(val label: String) {
  ALL("All"),
  POSITIVE("Positive (+)"),
  NEGATIVE("Negative (-)"),
}

data class DashboardSnapshot(
  val profile: UserProfile?,
  val tasks: List<HabitTask>,
  val dailyLogs: List<DailyLog>,
  val selectedDateKey: String,
  val selectedPeriod: ProgressPeriod,
  val taskFilter: TaskFilter,
  val periodSummary: PeriodSummary,
)

class LifeScoreViewModel(
  private val repository: LifeScoreRepository,
  private val currentUserId: String,
  private val initialDisplayName: String?,
  private val initialEmail: String?,
  private val initialPhotoUrl: String?,
) : ViewModel() {

  private val _selectedDateKey = MutableStateFlow(LifeScoreAnalytics.todayDateKey())
  val selectedDateKey: StateFlow<String> = _selectedDateKey.asStateFlow()

  private val _selectedPeriod = MutableStateFlow(ProgressPeriod.WEEKLY)
  val selectedPeriod: StateFlow<ProgressPeriod> = _selectedPeriod.asStateFlow()

  private val _taskFilter = MutableStateFlow(TaskFilter.ALL)
  val taskFilter: StateFlow<TaskFilter> = _taskFilter.asStateFlow()

  private val _snackbarMessage = MutableStateFlow<String?>(null)
  val snackbarMessage: StateFlow<String?> = _snackbarMessage.asStateFlow()

  private val _isBusy = MutableStateFlow(false)
  val isBusy: StateFlow<Boolean> = _isBusy.asStateFlow()

  private val profileFlow =
    repository
      .observeUserProfile(currentUserId)
      .map<UserProfile?, UiState<UserProfile?>> { UiState.Success(it) }
      .catch { error ->
        val rootError = unwrapFirestoreError(error) ?: throw error
        Log.w(TAG, "Error observing profile", rootError)
        emit(UiState.Error(rootError.message ?: "Failed to load profile"))
      }

  private val tasksFlow =
    repository
      .observeTasks(currentUserId)
      .map<List<HabitTask>, UiState<List<HabitTask>>> { UiState.Success(it) }
      .catch { error ->
        val rootError = unwrapFirestoreError(error) ?: throw error
        Log.w(TAG, "Error observing tasks", rootError)
        emit(UiState.Error(rootError.message ?: "Failed to load tasks"))
      }

  private val logsFlow =
    repository
      .observeDailyLogs(currentUserId)
      .map<List<DailyLog>, UiState<List<DailyLog>>> { UiState.Success(it) }
      .catch { error ->
        val rootError = unwrapFirestoreError(error) ?: throw error
        Log.w(TAG, "Error observing daily logs", rootError)
        emit(UiState.Error(rootError.message ?: "Failed to load daily logs"))
      }

  val dashboardState: StateFlow<UiState<DashboardSnapshot>> =
    combine(
        combine(profileFlow, tasksFlow, logsFlow) { p, t, l -> Triple(p, t, l) },
        _selectedDateKey,
        _selectedPeriod,
        _taskFilter,
      ) { (profileState, tasksState, logsState), dateKey, period, filter ->
        when {
          profileState is UiState.Error -> UiState.Error(profileState.message)
          tasksState is UiState.Error -> UiState.Error(tasksState.message)
          logsState is UiState.Error -> UiState.Error(logsState.message)
          profileState is UiState.Loading ||
            tasksState is UiState.Loading ||
            logsState is UiState.Loading -> UiState.Loading
          else -> {
            val profile = (profileState as UiState.Success).data
            val tasks = (tasksState as UiState.Success).data
            val logs = (logsState as UiState.Success).data
            val summary =
              LifeScoreAnalytics.buildPeriodSummary(
                period = period,
                logs = logs,
                tasks = tasks,
              )
            UiState.Success(
              DashboardSnapshot(
                profile = profile,
                tasks = tasks,
                dailyLogs = logs,
                selectedDateKey = dateKey,
                selectedPeriod = period,
                taskFilter = filter,
                periodSummary = summary,
              )
            )
          }
        }
      }
      .stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
        initialValue = UiState.Loading,
      )

  val leaderboardState: StateFlow<UiState<List<LeaderboardEntry>>> =
    repository
      .observeLeaderboard()
      .map<List<LeaderboardEntry>, UiState<List<LeaderboardEntry>>> { UiState.Success(it) }
      .catch { error ->
        val rootError = unwrapFirestoreError(error) ?: throw error
        Log.w(TAG, "Error observing leaderboard", rootError)
        emit(UiState.Error(rootError.message ?: "Failed to load leaderboard"))
      }
      .stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
        initialValue = UiState.Loading,
      )

  init {
    viewModelScope.launch {
      runCatching {
          repository.ensureUserInitialized(
            displayNameInput = initialDisplayName,
            emailInput = initialEmail,
            photoUrlInput = initialPhotoUrl,
          )
        }
        .onFailure { error ->
          if (error is CancellationException) throw error
          Log.w(TAG, "Account initialization failed", error)
          _snackbarMessage.value = error.localizedMessage ?: "Failed to initialize account"
        }
    }
  }

  fun selectDate(dateKey: String) {
    _selectedDateKey.value = dateKey
  }

  fun shiftSelectedDate(deltaDays: Int) {
    val today = LifeScoreAnalytics.todayDateKey()
    val current = _selectedDateKey.value
    val daysList = (0..29).map { LifeScoreAnalytics.dateKeyDaysAgo(it) }
    val currentIndex = daysList.indexOf(current).takeIf { it >= 0 } ?: 0
    val targetIndex = (currentIndex - deltaDays).coerceIn(0, daysList.lastIndex)
    _selectedDateKey.value = daysList.getOrElse(targetIndex) { today }
  }

  fun selectPeriod(period: ProgressPeriod) {
    _selectedPeriod.value = period
  }

  fun selectTaskFilter(filter: TaskFilter) {
    _taskFilter.value = filter
  }

  fun toggleTask(taskId: String, tasks: List<HabitTask>, logs: List<DailyLog>) {
    val dateKey = _selectedDateKey.value
    viewModelScope.launch {
      runCatching {
          repository.toggleTaskForDate(
            dateKey = dateKey,
            taskId = taskId,
            allTasks = tasks,
            existingLogs = logs,
          )
        }
        .onFailure { error ->
          if (error is CancellationException) throw error
          _snackbarMessage.value = error.localizedMessage ?: "Could not update task progress"
        }
    }
  }

  fun addTask(title: String, category: String, type: TaskType, points: Long, currentCount: Int) {
    viewModelScope.launch {
      _isBusy.value = true
      runCatching {
          repository.addTask(
            title = title,
            category = category,
            type = type,
            points = points,
            sortOrder = currentCount.toLong(),
          )
        }
        .onSuccess {
          _snackbarMessage.value = "Added \"$title\""
        }
        .onFailure { error ->
          if (error is CancellationException) throw error
          _snackbarMessage.value = error.localizedMessage ?: "Failed to add task"
        }
      _isBusy.value = false
    }
  }

  fun updateTask(task: HabitTask, title: String, category: String, type: TaskType, points: Long) {
    viewModelScope.launch {
      _isBusy.value = true
      runCatching {
          repository.updateTask(
            taskId = task.id,
            title = title,
            category = category,
            type = type,
            points = points,
            isActive = task.isActive,
            sortOrder = task.sortOrder,
          )
        }
        .onSuccess {
          _snackbarMessage.value = "Updated \"$title\""
        }
        .onFailure { error ->
          if (error is CancellationException) throw error
          _snackbarMessage.value = error.localizedMessage ?: "Failed to update task"
        }
      _isBusy.value = false
    }
  }

  fun deleteTask(task: HabitTask) {
    viewModelScope.launch {
      _isBusy.value = true
      runCatching { repository.deleteTask(task.id) }
        .onSuccess { _snackbarMessage.value = "Removed \"${task.title}\"" }
        .onFailure { error ->
          if (error is CancellationException) throw error
          _snackbarMessage.value = error.localizedMessage ?: "Failed to delete task"
        }
      _isBusy.value = false
    }
  }

  fun updateProfile(displayName: String, handle: String, bio: String, photoUrl: String) {
    viewModelScope.launch {
      _isBusy.value = true
      runCatching {
          repository.updateProfile(
            displayName = displayName,
            handle = handle,
            bio = bio,
            photoUrl = photoUrl,
          )
        }
        .onSuccess { _snackbarMessage.value = "Profile updated" }
        .onFailure { error ->
          if (error is CancellationException) throw error
          _snackbarMessage.value = error.localizedMessage ?: "Failed to update profile"
        }
      _isBusy.value = false
    }
  }

  fun clearMessage() {
    _snackbarMessage.value = null
  }

  private fun unwrapFirestoreError(error: Throwable): Throwable? {
    val firestoreError =
      generateSequence(error) { it.cause }
        .filterIsInstance<FirebaseFirestoreException>()
        .firstOrNull()
    if (firestoreError == null && error is CancellationException) return null
    return firestoreError ?: error
  }

  private companion object {
    const val TAG = "LifeScoreVM"
    const val STOP_TIMEOUT_MILLIS = 5000L
  }
}
