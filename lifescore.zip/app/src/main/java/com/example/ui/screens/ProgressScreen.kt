package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.DailyLog
import com.example.domain.LifeScoreAnalytics
import com.example.domain.ProgressPeriod
import com.example.ui.components.MountainScoreGraphCard
import com.example.ui.state.DashboardSnapshot
import com.example.ui.theme.EmeraldDeep
import com.example.ui.theme.EmeraldMintBorder
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.EmeraldTint
import com.example.ui.theme.InkMuted
import com.example.ui.theme.InkPrimary
import com.example.ui.theme.InkSecondary
import com.example.ui.theme.NegativeRose
import com.example.ui.theme.NegativeRoseBorder
import com.example.ui.theme.NegativeRoseTint
import com.example.ui.theme.PureWhite
import com.example.ui.theme.SlateBorder
import com.example.ui.theme.SoftSurface
import java.util.Locale

@Composable
fun ProgressScreen(
  snapshot: DashboardSnapshot,
  onSelectPeriod: (ProgressPeriod) -> Unit,
  modifier: Modifier = Modifier,
) {
  val summary = snapshot.periodSummary
  val recentLogs = snapshot.dailyLogs.sortedByDescending { it.dateKey }.take(14)

  Box(
    modifier = modifier.fillMaxSize().background(PureWhite),
    contentAlignment = Alignment.TopCenter,
  ) {
    LazyColumn(
      modifier = Modifier.widthIn(max = 720.dp).fillMaxSize(),
      contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 12.dp, bottom = 96.dp),
      verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
      item {
        Column {
          Text(
            text = "Progress & Analytics",
            style = MaterialTheme.typography.headlineMedium,
            color = InkPrimary,
          )
          Text(
            text = "Daily, weekly & monthly performance with negative dips",
            style = MaterialTheme.typography.bodyMedium,
            color = InkMuted,
          )
        }
      }

      // Daily / Weekly / Monthly Period Switcher
      item {
        Surface(
          modifier = Modifier.fillMaxWidth(),
          color = SoftSurface,
          shape = RoundedCornerShape(16.dp),
          border = BorderStroke(1.dp, SlateBorder),
        ) {
          Row(
            modifier = Modifier.fillMaxWidth().padding(4.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp),
          ) {
            ProgressPeriod.entries.forEach { period ->
              val selected = snapshot.selectedPeriod == period
              TextButton(
                onClick = { onSelectPeriod(period) },
                modifier = Modifier.weight(1f).height(44.dp).testTag("period_${period.name.lowercase()}"),
                shape = RoundedCornerShape(12.dp),
                colors =
                  ButtonDefaults.textButtonColors(
                    containerColor = if (selected) EmeraldPrimary else PureWhite.copy(alpha = 0f),
                    contentColor = if (selected) PureWhite else InkSecondary,
                  ),
              ) {
                Text(
                  text = period.label,
                  style = MaterialTheme.typography.labelLarge,
                  fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                )
              }
            }
          }
        }
      }

      // Interactive Mountain-Style Graph (supports positive peaks & negative valleys)
      item {
        MountainScoreGraphCard(points = summary.graphPoints)
      }

      // Period Summary Stat Grid
      item {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
          ) {
            MetricTile(
              label = "${summary.period.label} Net",
              value = formatSignedPts(summary.netScore),
              accentNegative = summary.netScore < 0L,
              modifier = Modifier.weight(1f),
            )
            MetricTile(
              label = "Daily Avg",
              value = String.format(Locale.US, "%+.1f pts", summary.averageScore),
              accentNegative = summary.averageScore < 0.0,
              modifier = Modifier.weight(1f),
            )
          }
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
          ) {
            MetricTile(
              label = "Highest Peak",
              value = formatSignedPts(summary.bestScore),
              accentNegative = summary.bestScore < 0L,
              modifier = Modifier.weight(1f),
            )
            MetricTile(
              label = "Lowest Valley",
              value = formatSignedPts(summary.lowestScore),
              accentNegative = summary.lowestScore < 0L,
              modifier = Modifier.weight(1f),
            )
          }
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
          ) {
            MetricTile(
              label = "Positive Earned",
              value = "+${summary.positivePoints} pts",
              accentNegative = false,
              modifier = Modifier.weight(1f),
            )
            MetricTile(
              label = "Negative Deducted",
              value = "-${summary.negativePoints} pts",
              accentNegative = summary.negativePoints > 0L,
              modifier = Modifier.weight(1f),
            )
          }
        }
      }

      // Recent Logged Days History
      item {
        Text(
          text = "Recent Daily Ledger",
          style = MaterialTheme.typography.titleMedium,
          color = InkPrimary,
          modifier = Modifier.padding(top = 4.dp),
        )
      }

      if (recentLogs.isEmpty()) {
        item {
          Surface(
            modifier = Modifier.fillMaxWidth(),
            color = SoftSurface,
            shape = RoundedCornerShape(16.dp),
            border = BorderStroke(1.dp, SlateBorder),
          ) {
            Text(
              text = "Complete tasks on Today's checklist to build your LifeScore mountain history.",
              style = MaterialTheme.typography.bodyMedium,
              color = InkMuted,
              modifier = Modifier.padding(16.dp),
            )
          }
        }
      } else {
        items(recentLogs, key = { it.dateKey }) { log ->
          DailyLogHistoryRow(log = log)
        }
      }
    }
  }
}

@Composable
private fun MetricTile(
  label: String,
  value: String,
  accentNegative: Boolean,
  modifier: Modifier = Modifier,
) {
  Card(
    modifier = modifier,
    shape = RoundedCornerShape(16.dp),
    colors = CardDefaults.cardColors(containerColor = SoftSurface),
    border = BorderStroke(1.dp, SlateBorder),
  ) {
    Column(modifier = Modifier.padding(14.dp)) {
      Text(
        text = label,
        style = MaterialTheme.typography.labelSmall,
        color = InkMuted,
      )
      Spacer(modifier = Modifier.height(4.dp))
      Text(
        text = value,
        style = MaterialTheme.typography.titleLarge,
        fontWeight = FontWeight.Bold,
        color = if (accentNegative) NegativeRose else EmeraldPrimary,
      )
    }
  }
}

@Composable
private fun DailyLogHistoryRow(log: DailyLog) {
  val isNegative = log.netScore < 0L
  Surface(
    modifier = Modifier.fillMaxWidth(),
    color = PureWhite,
    shape = RoundedCornerShape(16.dp),
    border = BorderStroke(1.dp, SlateBorder),
  ) {
    Row(
      modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Column {
        Text(
          text = LifeScoreAnalytics.formatDisplayDate(log.dateKey),
          style = MaterialTheme.typography.titleMedium,
          color = InkPrimary,
        )
        Text(
          text = "+${log.positivePoints} pos  •  -${log.negativePoints} neg",
          style = MaterialTheme.typography.labelSmall,
          color = InkMuted,
        )
      }

      Surface(
        color = if (isNegative) NegativeRoseTint else EmeraldTint,
        shape = RoundedCornerShape(10.dp),
        border = BorderStroke(1.dp, if (isNegative) NegativeRoseBorder else EmeraldMintBorder),
      ) {
        Text(
          text = formatSignedPts(log.netScore),
          style = MaterialTheme.typography.labelLarge,
          fontWeight = FontWeight.Bold,
          color = if (isNegative) NegativeRose else EmeraldDeep,
          modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
        )
      }
    }
  }
}

private fun formatSignedPts(value: Long): String =
  if (value > 0L) "+$value pts" else "$value pts"
