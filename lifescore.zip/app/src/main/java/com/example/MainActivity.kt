package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.AutoGraph
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material.icons.outlined.Leaderboard
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material.icons.rounded.AutoGraph
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Leaderboard
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.NavigationRailItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.credentials.CredentialManager
import androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory.Companion.APPLICATION_KEY
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.example.data.repository.LifeScoreRepository
import com.example.ui.auth.SignInScreen
import com.example.ui.auth.authStateFlow
import com.example.ui.auth.signOutUser
import com.example.ui.screens.LeaderboardScreen
import com.example.ui.screens.ProfileScreen
import com.example.ui.screens.ProgressScreen
import com.example.ui.screens.TodayChecklistScreen
import com.example.ui.state.LifeScoreViewModel
import com.example.ui.state.UiState
import com.example.ui.theme.EmeraldDeep
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.EmeraldTint
import com.example.ui.theme.InkMuted
import com.example.ui.theme.LifeScoreTheme
import com.example.ui.theme.NegativeRose
import com.example.ui.theme.PureWhite
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.FirebaseFirestore

enum class LifeScoreTab(
  val label: String,
  val selectedIcon: ImageVector,
  val unselectedIcon: ImageVector,
  val testTag: String,
) {
  TODAY("Today", Icons.Rounded.CheckCircle, Icons.Outlined.CheckCircle, "nav_today"),
  PROGRESS("Progress", Icons.Rounded.AutoGraph, Icons.Outlined.AutoGraph, "nav_progress"),
  LEADERBOARD("Ranks", Icons.Rounded.Leaderboard, Icons.Outlined.Leaderboard, "nav_leaderboard"),
  PROFILE("Profile", Icons.Rounded.Person, Icons.Outlined.Person, "nav_profile"),
}

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    setContent {
      LifeScoreTheme {
        AppContent()
      }
    }
  }
}

@Composable
fun AppContent(auth: FirebaseAuth = Firebase.auth) {
  val currentUser by auth.authStateFlow().collectAsStateWithLifecycle(initialValue = auth.currentUser)
  val user = currentUser

  if (user == null) {
    SignInScreen(onAuthSuccess = {})
  } else {
    key(user.uid) {
      LifeScoreAuthenticatedShell(
        currentUserId = user.uid,
        displayName = user.displayName,
        email = user.email,
        photoUrl = user.photoUrl?.toString(),
      )
    }
  }
}

@Composable
fun LifeScoreAuthenticatedShell(
  currentUserId: String,
  displayName: String?,
  email: String?,
  photoUrl: String?,
) {
  val context = LocalContext.current
  val coroutineScope = rememberCoroutineScope()
  val credentialManager = remember(context) { CredentialManager.create(context) }

  val viewModel: LifeScoreViewModel =
    viewModel(
      key = currentUserId,
      factory =
        viewModelFactory {
          initializer {
            val app =
              checkNotNull(this[APPLICATION_KEY]) {
                "APPLICATION_KEY missing from CreationExtras"
              }
            val databaseId = app.getString(R.string.firestore_database_id)
            val db = FirebaseFirestore.getInstance(databaseId)
            LifeScoreViewModel(
              repository = LifeScoreRepository(db),
              currentUserId = currentUserId,
              initialDisplayName = displayName,
              initialEmail = email,
              initialPhotoUrl = photoUrl,
            )
          }
        },
    )

  val dashboardState by viewModel.dashboardState.collectAsStateWithLifecycle()
  val leaderboardState by viewModel.leaderboardState.collectAsStateWithLifecycle()
  val snackbarMessage by viewModel.snackbarMessage.collectAsStateWithLifecycle()

  var selectedTab by rememberSaveable { mutableStateOf(LifeScoreTab.TODAY) }
  val snackbarHostState = remember { SnackbarHostState() }

  LaunchedEffect(snackbarMessage) {
    val msg = snackbarMessage
    if (msg != null) {
      snackbarHostState.showSnackbar(msg)
      viewModel.clearMessage()
    }
  }

  if (selectedTab != LifeScoreTab.TODAY) {
    BackHandler { selectedTab = LifeScoreTab.TODAY }
  }

  BoxWithConstraints(modifier = Modifier.fillMaxSize().background(PureWhite)) {
    val useRail = maxWidth >= 680.dp

    Scaffold(
      modifier = Modifier.fillMaxSize(),
      containerColor = PureWhite,
      snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
      bottomBar = {
        if (!useRail) {
          NavigationBar(containerColor = PureWhite, tonalElevation = 0.dp) {
            LifeScoreTab.entries.forEach { tab ->
              val isSelected = selectedTab == tab
              NavigationBarItem(
                selected = isSelected,
                onClick = { selectedTab = tab },
                icon = {
                  Icon(
                    imageVector = if (isSelected) tab.selectedIcon else tab.unselectedIcon,
                    contentDescription = tab.label,
                  )
                },
                label = { Text(tab.label, style = MaterialTheme.typography.labelSmall) },
                modifier = Modifier.testTag(tab.testTag),
                colors =
                  NavigationBarItemDefaults.colors(
                    selectedIconColor = EmeraldPrimary,
                    selectedTextColor = EmeraldDeep,
                    indicatorColor = EmeraldTint,
                    unselectedIconColor = InkMuted,
                    unselectedTextColor = InkMuted,
                  ),
              )
            }
          }
        }
      },
    ) { innerPadding ->
      Row(modifier = Modifier.fillMaxSize().padding(innerPadding)) {
        if (useRail) {
          NavigationRail(
            containerColor = PureWhite,
            modifier = Modifier.statusBarsPadding().padding(top = 12.dp),
          ) {
            LifeScoreTab.entries.forEach { tab ->
              val isSelected = selectedTab == tab
              NavigationRailItem(
                selected = isSelected,
                onClick = { selectedTab = tab },
                icon = {
                  Icon(
                    imageVector = if (isSelected) tab.selectedIcon else tab.unselectedIcon,
                    contentDescription = tab.label,
                  )
                },
                label = { Text(tab.label, style = MaterialTheme.typography.labelSmall) },
                modifier = Modifier.testTag(tab.testTag),
                colors =
                  NavigationRailItemDefaults.colors(
                    selectedIconColor = EmeraldPrimary,
                    selectedTextColor = EmeraldDeep,
                    indicatorColor = EmeraldTint,
                    unselectedIconColor = InkMuted,
                    unselectedTextColor = InkMuted,
                  ),
              )
            }
            Spacer(modifier = Modifier.weight(1f))
          }
        }

        Column(modifier = Modifier.weight(1f).fillMaxSize()) {
          when (val state = dashboardState) {
            UiState.Loading -> {
              BoxWithConstraints(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center,
              ) {
                CircularProgressIndicator(color = EmeraldPrimary)
              }
            }
            is UiState.Error -> {
              BoxWithConstraints(
                modifier = Modifier.fillMaxSize().padding(24.dp),
                contentAlignment = Alignment.Center,
              ) {
                Text(
                  text = state.message,
                  style = MaterialTheme.typography.bodyLarge,
                  color = NegativeRose,
                )
              }
            }
            is UiState.Success -> {
              val snapshot = state.data
              when (selectedTab) {
                LifeScoreTab.TODAY -> {
                  TodayChecklistScreen(
                    snapshot = snapshot,
                    onToggleTask = { taskId ->
                      viewModel.toggleTask(taskId, snapshot.tasks, snapshot.dailyLogs)
                    },
                    onShiftDate = { delta -> viewModel.shiftSelectedDate(delta) },
                    onSelectFilter = { filter -> viewModel.selectTaskFilter(filter) },
                    onAddTask = { title, category, type, pts ->
                      viewModel.addTask(title, category, type, pts, snapshot.tasks.size)
                    },
                    onUpdateTask = { task, title, category, type, pts ->
                      viewModel.updateTask(task, title, category, type, pts)
                    },
                    onDeleteTask = { task -> viewModel.deleteTask(task) },
                  )
                }
                LifeScoreTab.PROGRESS -> {
                  ProgressScreen(
                    snapshot = snapshot,
                    onSelectPeriod = { period -> viewModel.selectPeriod(period) },
                  )
                }
                LifeScoreTab.LEADERBOARD -> {
                  LeaderboardScreen(
                    leaderboardState = leaderboardState,
                    currentUserId = currentUserId,
                  )
                }
                LifeScoreTab.PROFILE -> {
                  ProfileScreen(
                    profile = snapshot.profile,
                    userEmail = email,
                    onUpdateProfile = { name, handle, bio, photo ->
                      viewModel.updateProfile(name, handle, bio, photo)
                    },
                    onSignOut = {
                      signOutUser(
                        credentialManager = credentialManager,
                        scope = coroutineScope,
                      )
                    },
                  )
                }
              }
            }
          }
        }
      }
    }
  }
}
